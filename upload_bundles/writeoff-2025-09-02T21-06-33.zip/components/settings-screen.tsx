"use client";

import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/simple-select';
import { 
  ArrowLeft, 
  User, 
  Mail, 
  Briefcase, 
  DollarSign, 
  MapPin, 
  FileText,
  Save,
  Loader2,
  CheckCircle,
  AlertCircle,
  BookOpen,
  X
} from 'lucide-react';
import { getUserProfile, upsertUserProfile, UserProfile } from '@/lib/firebase/profiles';

// Simple wrapper for Select components
const SimpleSelectWrapper: React.FC<{
  value: string;
  onValueChange: (value: string) => void;
  placeholder: string;
  options: { value: string; label: string }[];
}> = ({ value, onValueChange, placeholder, options }) => {
  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger className="h-12 rounded-xl border-2">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        {options.map((option) => (
          <SelectItem key={option.value} value={option.value}>
            {option.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};

interface SettingsScreenProps {
  user: {
    id: string;
    email?: string;
    user_metadata?: {
      name?: string;
    };
  };
  onBack: () => void;
  onNavigate: (screen: string) => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({ 
  user, 
  onBack, 
  onNavigate 
}) => {
  const [profile, setProfile] = useState({
    name: user?.user_metadata?.name || '',
    email: user?.email || '',
    profession: '',
    income: '',
    state: '',
    filing_status: ''
  });
  
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [showWriteOffsModal, setShowWriteOffsModal] = useState(false);

  // Load existing profile data
  useEffect(() => {
    const loadProfile = async () => {
      try {
        setIsLoading(true);
        console.log('Loading profile for user:', {
          id: user.id,
          email: user.email,
          metadata: user.user_metadata
        });
        
        const { data: existingProfile, error } = await getUserProfile(user.id);
        
        if (error && error.code !== 'PGRST116') {
          console.error('Error loading profile:', {
            message: (error as any)?.message,
            code: (error as any)?.code,
            details: (error as any)?.details,
            hint: (error as any)?.hint,
            fullError: error
          });
          setErrorMessage('Failed to load profile data');
          return;
        }

        if (existingProfile) {
          setProfile({
            name: existingProfile.name || user?.user_metadata?.name || '',
            email: existingProfile.email || user?.email || '',
            profession: existingProfile.profession || '',
            income: existingProfile.income || '',
            state: existingProfile.state || '',
            filing_status: existingProfile.filing_status || ''
          });
        }
      } catch (err) {
        console.error('Error loading profile:', err);
        setErrorMessage('Failed to load profile data');
      } finally {
        setIsLoading(false);
      }
    };

    loadProfile();
  }, [user.id, user?.user_metadata?.name, user?.email]);

  const handleInputChange = (field: string, value: string) => {
    setProfile(prev => ({
      ...prev,
      [field]: value
    }));
    setSaveStatus('idle');
  };

  const handleSave = async () => {
    try {
      setIsSaving(true);
      setSaveStatus('idle');
      setErrorMessage('');

      console.log('Attempting to save profile for user:', user.id);

      const profileData = {
        user_id: user.id,
        email: profile.email,
        name: profile.name,
        profession: profile.profession,
        income: profile.income,
        state: profile.state,
        filing_status: profile.filing_status
      };

      console.log('Profile data to save:', profileData);

      const { data, error } = await upsertUserProfile(user.id, profileData);

      if (error) {
        console.error('Error saving profile:', {
          message: (error as any)?.message,
          code: (error as any)?.code,
          details: (error as any)?.details,
          hint: (error as any)?.hint,
          fullError: error
        });
        setSaveStatus('error');
        setErrorMessage(`Failed to save profile: ${(error as any)?.message || 'Unknown error'}`);
        return;
      }

      console.log('Profile saved successfully:', data);
      setSaveStatus('success');
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSaveStatus('idle');
      }, 3000);

    } catch (err) {
      console.error('Error saving profile (catch block):', {
        message: err instanceof Error ? err.message : 'Unknown error',
        stack: err instanceof Error ? err.stack : undefined,
        fullError: err
      });
      setSaveStatus('error');
      setErrorMessage(`Failed to save profile: ${err instanceof Error ? err.message : 'Unknown error'}`);
    } finally {
      setIsSaving(false);
    }
  };

  const isFormValid = profile.name && profile.email && profile.profession && profile.income && profile.state && profile.filing_status;

  const incomeOptions = [
    { value: 'under_25k', label: 'Under $25,000' },
    { value: '25k_50k', label: '$25,000 - $50,000' },
    { value: '50k_75k', label: '$50,000 - $75,000' },
    { value: '75k_100k', label: '$75,000 - $100,000' },
    { value: '100k_150k', label: '$100,000 - $150,000' },
    { value: '150k_250k', label: '$150,000 - $250,000' },
    { value: 'over_250k', label: 'Over $250,000' }
  ];

  const stateOptions = [
    { value: 'AL', label: 'Alabama' },
    { value: 'AK', label: 'Alaska' },
    { value: 'AZ', label: 'Arizona' },
    { value: 'AR', label: 'Arkansas' },
    { value: 'CA', label: 'California' },
    { value: 'CO', label: 'Colorado' },
    { value: 'CT', label: 'Connecticut' },
    { value: 'DE', label: 'Delaware' },
    { value: 'FL', label: 'Florida' },
    { value: 'GA', label: 'Georgia' },
    { value: 'HI', label: 'Hawaii' },
    { value: 'ID', label: 'Idaho' },
    { value: 'IL', label: 'Illinois' },
    { value: 'IN', label: 'Indiana' },
    { value: 'IA', label: 'Iowa' },
    { value: 'KS', label: 'Kansas' },
    { value: 'KY', label: 'Kentucky' },
    { value: 'LA', label: 'Louisiana' },
    { value: 'ME', label: 'Maine' },
    { value: 'MD', label: 'Maryland' },
    { value: 'MA', label: 'Massachusetts' },
    { value: 'MI', label: 'Michigan' },
    { value: 'MN', label: 'Minnesota' },
    { value: 'MS', label: 'Mississippi' },
    { value: 'MO', label: 'Missouri' },
    { value: 'MT', label: 'Montana' },
    { value: 'NE', label: 'Nebraska' },
    { value: 'NV', label: 'Nevada' },
    { value: 'NH', label: 'New Hampshire' },
    { value: 'NJ', label: 'New Jersey' },
    { value: 'NM', label: 'New Mexico' },
    { value: 'NY', label: 'New York' },
    { value: 'NC', label: 'North Carolina' },
    { value: 'ND', label: 'North Dakota' },
    { value: 'OH', label: 'Ohio' },
    { value: 'OK', label: 'Oklahoma' },
    { value: 'OR', label: 'Oregon' },
    { value: 'PA', label: 'Pennsylvania' },
    { value: 'RI', label: 'Rhode Island' },
    { value: 'SC', label: 'South Carolina' },
    { value: 'SD', label: 'South Dakota' },
    { value: 'TN', label: 'Tennessee' },
    { value: 'TX', label: 'Texas' },
    { value: 'UT', label: 'Utah' },
    { value: 'VT', label: 'Vermont' },
    { value: 'VA', label: 'Virginia' },
    { value: 'WA', label: 'Washington' },
    { value: 'WV', label: 'West Virginia' },
    { value: 'WI', label: 'Wisconsin' },
    { value: 'WY', label: 'Wyoming' }
  ];

  const filingStatusOptions = [
    { value: 'single', label: 'Single' },
    { value: 'married_jointly', label: 'Married Filing Jointly' },
    { value: 'married_separately', label: 'Married Filing Separately' },
    { value: 'head_of_household', label: 'Head of Household' },
    { value: 'qualifying_widow', label: 'Qualifying Widow(er)' }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 flex items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="w-8 h-8 animate-spin mx-auto text-blue-600" />
          <p className="text-slate-600">Loading profile settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <div className="bg-white border-b border-blue-100 sticky top-0 z-50 shadow-sm">
        <div className="flex items-center justify-between p-6">
          <button 
            onClick={onBack}
            className="w-12 h-12 bg-white border border-slate-200 rounded-2xl flex items-center justify-center text-slate-600 hover:text-slate-800 hover:bg-slate-50 transition-all duration-200 shadow-md"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="text-center">
            <div className="h-8 w-24 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-2">
              <span className="text-white font-bold text-sm">WriteOff</span>
            </div>
            <h1 className="text-xl font-semibold text-slate-900 mb-1">
              <span className="text-blue-600 font-bold">Settings</span>
            </h1>
            <p className="text-sm text-slate-600">Manage your profile and preferences</p>
          </div>
          <div className="w-12"></div>
        </div>
      </div>

      <div className="p-4 lg:p-6 max-w-2xl mx-auto">
        {/* Save Status Messages */}
        {saveStatus === 'success' && (
          <Card className="p-4 bg-emerald-50 border-emerald-200 shadow-lg mb-6">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-emerald-600" />
              <div>
                <p className="text-emerald-800 font-medium">Profile Updated Successfully</p>
                <p className="text-emerald-600 text-sm">Your changes have been saved.</p>
              </div>
            </div>
          </Card>
        )}

        {saveStatus === 'error' && (
          <Card className="p-4 bg-red-50 border-red-200 shadow-lg mb-6">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-6 h-6 text-red-600" />
              <div>
                <p className="text-red-800 font-medium">Save Failed</p>
                <p className="text-red-600 text-sm">{errorMessage}</p>
              </div>
            </div>
          </Card>
        )}

        {/* Profile Settings Card */}
        <Card className="p-4 lg:p-8 bg-white border-0 shadow-xl">
          <div className="text-center mb-6 lg:mb-8">
            <div className="w-16 h-16 lg:w-20 lg:h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-3 lg:mb-4">
              <User className="w-8 h-8 lg:w-10 lg:h-10 text-white" />
            </div>
            <h2 className="text-xl lg:text-2xl font-bold text-slate-900 mb-2">Profile Settings</h2>
            <p className="text-sm lg:text-base text-slate-600">Update your personal information and tax preferences</p>
          </div>

          <div className="space-y-6">
            {/* Personal Information Section */}
            <div>
              <h3 className="text-base lg:text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <User className="w-4 h-4 lg:w-5 lg:h-5 text-blue-600" />
                Personal Information
              </h3>
              
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Full Name
                  </label>
                  <Input
                    type="text"
                    value={profile.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder="Enter your full name"
                    className="h-12 rounded-xl border-2"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Email Address
                  </label>
                  <Input
                    type="email"
                    value={profile.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    placeholder="Enter your email"
                    className="h-12 rounded-xl border-2"
                  />
                </div>
              </div>
            </div>

            {/* Professional Information Section */}
            <div>
              <h3 className="text-base lg:text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <Briefcase className="w-4 h-4 lg:w-5 lg:h-5 text-blue-600" />
                Professional Information
              </h3>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Profession
                </label>
                <Input
                  type="text"
                  value={profile.profession}
                  onChange={(e) => handleInputChange('profession', e.target.value)}
                  placeholder="e.g., Software Engineer, Consultant, Freelancer"
                  className="h-12 rounded-xl border-2"
                />
              </div>
            </div>

            {/* Tax Information Section */}
            <div>
              <h3 className="text-base lg:text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <FileText className="w-4 h-4 lg:w-5 lg:h-5 text-blue-600" />
                Tax Information
              </h3>
              
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Annual Income
                  </label>
                  <SimpleSelectWrapper
                    value={profile.income}
                    onValueChange={(value: string) => handleInputChange('income', value)}
                    placeholder="Select income range"
                    options={incomeOptions}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    State
                  </label>
                  <SimpleSelectWrapper
                    value={profile.state}
                    onValueChange={(value: string) => handleInputChange('state', value)}
                    placeholder="Select your state"
                    options={stateOptions}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Filing Status
                  </label>
                  <SimpleSelectWrapper
                    value={profile.filing_status}
                    onValueChange={(value: string) => handleInputChange('filing_status', value)}
                    placeholder="Select filing status"
                    options={filingStatusOptions}
                  />
                </div>
              </div>
            </div>

            {/* Save Button */}
            <div className="pt-6 border-t border-slate-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={handleSave}
                  disabled={!isFormValid || isSaving}
                  className="flex-1 h-14 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-2xl transition-all duration-300 shadow-lg text-base font-semibold"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="w-5 h-5 mr-2" />
                      Save Changes
                    </>
                  )}
                </Button>

                <Button
                  onClick={onBack}
                  variant="outline"
                  className="h-14 px-8 rounded-2xl border-2"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </Card>

        {/* Additional Settings */}
        <Card className="p-4 lg:p-6 bg-white border-0 shadow-xl mt-6">
          <h3 className="text-base lg:text-lg font-semibold text-slate-900 mb-4">Bank Account Management</h3>
          <div className="space-y-4">
            <Button 
              onClick={() => onNavigate('plaid-link')}
              className="w-full h-14 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl flex items-center justify-center gap-3"
            >
              <DollarSign className="w-5 h-5" />
              Connect Bank Account with Plaid
            </Button>
            
            <Button 
              onClick={() => onNavigate('plaid')}
              variant="outline"
              className="w-full h-12 justify-center gap-3 rounded-xl"
            >
              <DollarSign className="w-4 h-4" />
              Manage Connected Accounts
            </Button>
          </div>
        </Card>

        {/* Quick Actions */}
        <Card className="p-4 lg:p-6 bg-white border-0 shadow-xl mt-6">
          <h3 className="text-base lg:text-lg font-semibold text-slate-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-1 gap-4">
            <Button 
              onClick={() => setShowWriteOffsModal(true)}
              className="h-12 justify-start gap-3 bg-blue-600 hover:bg-blue-700 text-white"
            >
              <BookOpen className="w-4 h-4" />
              Learn about write-offs
            </Button>
            <Button 
              onClick={() => onNavigate('dashboard')}
              variant="outline"
              className="h-12 justify-start gap-3"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Dashboard
            </Button>
          </div>
        </Card>
      </div>

      {/* Write-offs Educational Modal */}
      {showWriteOffsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 p-4 lg:p-6 flex items-center justify-between rounded-t-2xl">
              <h2 className="text-xl lg:text-2xl font-bold text-gray-900">Learn About Tax Write-offs</h2>
              <button 
                onClick={() => setShowWriteOffsModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6 text-gray-600" />
              </button>
            </div>
            
            <div className="p-4 lg:p-6 space-y-6 lg:space-y-8">
              {/* Introduction */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 lg:p-6">
                <h3 className="text-lg lg:text-xl font-semibold text-blue-900 mb-3">What are Tax Write-offs?</h3>
                <p className="text-sm lg:text-base text-blue-800">
                  Tax write-offs (also called deductions) are legitimate business expenses that reduce your taxable income. 
                  As a freelancer or business owner, you can deduct ordinary and necessary expenses related to your work, 
                  potentially saving you 20-30% of those costs in taxes.
                </p>
              </div>

              {/* Common Deductible Expenses */}
              <div>
                <h3 className="text-lg lg:text-xl font-semibold text-gray-900 mb-4">✅ Common Deductible Expenses</h3>
                <div className="grid grid-cols-1 gap-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-800 mb-2">Office & Equipment</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Computer, software, and tech equipment</li>
                      <li>• Office supplies and furniture</li>
                      <li>• Internet and phone bills (business portion)</li>
                      <li>• Home office expenses</li>
                    </ul>
                  </div>
                  
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-800 mb-2">Professional Services</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Legal and accounting fees</li>
                      <li>• Business consulting</li>
                      <li>• Professional development courses</li>
                      <li>• Industry conferences and workshops</li>
                    </ul>
                  </div>
                  
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-800 mb-2">Travel & Transportation</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Business travel (flights, hotels)</li>
                      <li>• Mileage for business trips</li>
                      <li>• Parking and tolls</li>
                      <li>• Uber/Lyft for business purposes</li>
                    </ul>
                  </div>
                  
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-800 mb-2">Business Operations</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Marketing and advertising</li>
                      <li>• Business insurance</li>
                      <li>• Bank fees and merchant processing</li>
                      <li>• Business licenses and permits</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Meals - Special Rules */}
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 lg:p-6">
                <h3 className="text-lg lg:text-xl font-semibold text-yellow-800 mb-3">🍽️ Business Meals - Special Rules</h3>
                <p className="text-sm lg:text-base text-yellow-700 mb-3">
                  Business meals are generally 50% deductible, but there are exceptions:
                </p>
                <ul className="text-sm text-yellow-700 space-y-2">
                  <li>• <strong>Client meetings:</strong> 50% deductible when discussing business</li>
                  <li>• <strong>Team meals:</strong> 50% deductible for employee meals</li>
                  <li>• <strong>Office snacks:</strong> 100% deductible for office-provided food</li>
                  <li>• <strong>Travel meals:</strong> 50% deductible when traveling for business</li>
                </ul>
              </div>

              {/* Non-Deductible Expenses */}
              <div>
                <h3 className="text-lg lg:text-xl font-semibold text-gray-900 mb-4">❌ Generally NOT Deductible</h3>
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <ul className="text-sm text-red-700 space-y-2">
                    <li>• Personal groceries and household items</li>
                    <li>• Personal clothing (unless it's a uniform)</li>
                    <li>• Personal entertainment and hobbies</li>
                    <li>• Commuting to your regular workplace</li>
                    <li>• Personal insurance and medical expenses</li>
                    <li>• Personal credit card interest</li>
                    <li>• Fines and penalties</li>
                  </ul>
                </div>
              </div>

              {/* Key Requirements */}
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 lg:p-6">
                <h3 className="text-lg lg:text-xl font-semibold text-gray-800 mb-3">📋 Key Requirements for Deductions</h3>
                <div className="grid grid-cols-1 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-700 mb-2">1. Ordinary & Necessary</h4>
                    <p className="text-sm text-gray-600">
                      The expense must be common and accepted in your industry, and helpful for your business.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-700 mb-2">2. Business Purpose</h4>
                    <p className="text-sm text-gray-600">
                      The expense must be directly related to your business activities, not personal use.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-700 mb-2">3. Keep Records</h4>
                    <p className="text-sm text-gray-600">
                      Maintain receipts, invoices, and records showing the business purpose and amount.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-700 mb-2">4. Reasonable Amount</h4>
                    <p className="text-sm text-gray-600">
                      The expense amount should be reasonable and not excessive for the business benefit.
                    </p>
                  </div>
                </div>
              </div>

              {/* Tips */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 lg:p-6">
                <h3 className="text-lg lg:text-xl font-semibold text-blue-800 mb-3">💡 Pro Tips</h3>
                <ul className="text-sm text-blue-700 space-y-2">
                  <li>• <strong>Track everything:</strong> Use WriteOff to automatically categorize your expenses</li>
                  <li>• <strong>Mixed-use items:</strong> Only deduct the business portion (e.g., 70% of home internet if 70% is for business)</li>
                  <li>• <strong>When in doubt:</strong> Consult with a tax professional</li>
                  <li>• <strong>Stay organized:</strong> Keep digital copies of all receipts and invoices</li>
                  <li>• <strong>Be conservative:</strong> Only claim legitimate business expenses</li>
                </ul>
              </div>

              {/* Disclaimer */}
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                <p className="text-xs text-amber-700">
                  <strong>Disclaimer:</strong> This information is for educational purposes only and should not be considered tax advice. 
                  Tax laws vary by location and situation. Always consult with a qualified tax professional for advice specific to your circumstances.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
