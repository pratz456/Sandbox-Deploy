/**
 * WriteOff Dashboard with AI-Powered Transaction Analysis
 * 
 * Features:
 * - Plaid integration for automatic bank transaction import
 * - OpenAI GPT-4 analysis for tax deductibility classification
 * - Real-time confidence scoring for AI decisions
 * - Manual transaction entry and editing
 * - Comprehensive expense tracking and categorization
 * 
 * AI Integration:
 * - Analyzes merchant name, amount, category, and date
 * - Provides deductibility determination with reasoning
 * - Confidence scores from 0-100% for each analysis
 * - Fallback to manual review for low-confidence results
 */

import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { useRouter } from 'next/navigation';
import { makeAuthenticatedRequest } from '@/lib/firebase/api-client';

const writeOffLogo = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iOCIgZmlsbD0iIzMzNjZDQyIvPgo8dGV4dCB4PSIxNiIgeT0iMjIiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZm9udC13ZWlnaHQ9ImJvbGQiIGZpbGw9IndoaXRlIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5XPC90ZXh0Pgo8L3N2Zz4K';

// Icon components
const DollarSignIcon = () => (
  <svg className="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
  </svg>
);

const TrendingUpIcon = () => (
  <svg className="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
  </svg>
);

const ClockIcon = () => (
  <svg className="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const CheckCircleIcon = () => (
  <svg className="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const SettingsIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

const BarChartIcon = () => (
  <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
  </svg>
);

const FileTextIcon = () => (
  <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
  </svg>
);

const LogOutIcon = () => (
  <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
  </svg>
);

const SparklesIcon = () => (
  <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
  </svg>
);

const RefreshCwIcon = () => (
  <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
  </svg>
);

const CameraIcon = () => (
  <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

// Category icon components
const PlaneIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
  </svg>
);

const UtensilsIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6-5v6a2 2 0 01-2 2H9a2 2 0 01-2-2v-6m6 0V9a2 2 0 00-2-2H9a2 2 0 00-2 2v4.01" />
  </svg>
);

const BuildingIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
  </svg>
);

const MonitorIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
  </svg>
);

const HomeIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
  </svg>
);

const ZapIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
  </svg>
);

interface DashboardScreenProps {
  profile: any;
  transactions: any[];
  onNavigate: (screen: string) => void;
  onTransactionClick: (transaction: any) => void;
  onAnalyzeTransactions?: () => void;
  analyzingTransactions?: boolean;
  onSignOut?: () => void;
}

// Helper function to format category names
const formatCategory = (category: string): string => {
  if (!category) return 'Needs review';
  return category
    .toLowerCase()
    .split('_')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

// Helper function to get category color
const getCategoryColor = (category: string): string => {
  const categoryColors: { [key: string]: string } = {
    'PROFESSIONAL_SERVICES': 'bg-blue-500',
    'OFFICE_EXPENSE': 'bg-purple-500',
    'MEALS': 'bg-orange-500',
    'TRANSPORTATION_TAXIS_AND_RIDE_SHARES': 'bg-green-500',
    'TRAVEL_FLIGHTS': 'bg-indigo-500',
    'FOOD_AND_DRINK_COFFEE': 'bg-orange-500',
    'FOOD_AND_DRINK_FAST_FOOD': 'bg-orange-500',
    'GENERAL_MERCHANDISE_OTHER_GENERAL_MERCHANDISE': 'bg-gray-500',
    'GENERAL_SERVICES_ACCOUNTING_AND_FINANCIAL_PLANNING': 'bg-blue-500',
    'PERSONAL_CARE_GYMS_AND_FITNESS_CENTERS': 'bg-pink-500',
    'ENTERTAINMENT_SPORTING_EVENTS_AMUSEMENT_PARKS_AND_MUSEUMS': 'bg-purple-500',
    'GENERAL_MERCHANDISE_SPORTING_GOODS': 'bg-green-500',
    'INCOME_WAGES': 'bg-green-500',
    'LOAN_PAYMENTS_CREDIT_CARD_PAYMENT': 'bg-red-500'
  };
  
  return categoryColors[category] || 'bg-gray-500';
};

// Helper function to get category icon
const getCategoryIcon = (category: string) => {
  const categoryIcons: { [key: string]: any } = {
    'TRAVEL_FLIGHTS': PlaneIcon,
    'TRANSPORTATION_TAXIS_AND_RIDE_SHARES': PlaneIcon,
    'MEALS': UtensilsIcon,
    'FOOD_AND_DRINK_COFFEE': UtensilsIcon,
    'FOOD_AND_DRINK_FAST_FOOD': UtensilsIcon,
    'PROFESSIONAL_SERVICES': BuildingIcon,
    'GENERAL_SERVICES_ACCOUNTING_AND_FINANCIAL_PLANNING': BuildingIcon,
    'SOFTWARE': MonitorIcon,
    'OFFICE_EXPENSE': MonitorIcon,
    'HOME_OFFICE': HomeIcon,
    'UTILITIES': ZapIcon,
    'GENERAL_MERCHANDISE_OTHER_GENERAL_MERCHANDISE': BuildingIcon
  };
  
  return categoryIcons[category] || BuildingIcon;
};

export default function DashboardScreen({ 
  profile, 
  transactions, 
  onNavigate, 
  onTransactionClick,
  onAnalyzeTransactions,
  analyzingTransactions = false,
  onSignOut
}: DashboardScreenProps) {
  const router = useRouter();
  const [analysisResult, setAnalysisResult] = useState<{analyzed: number, total: number} | null>(null);
  const [analysisProgress, setAnalysisProgress] = useState<{current: number, total: number} | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [taxSavingsData, setTaxSavingsData] = useState<any>(null);
  const [loadingTaxSavings, setLoadingTaxSavings] = useState(true);

  // Fetch tax savings data
  useEffect(() => {
    const fetchTaxSavings = async () => {
      if (!profile?.id) return;
      
      try {
        setLoadingTaxSavings(true);
        const response = await makeAuthenticatedRequest('/api/tax-savings');
        if (response.ok) {
          const data = await response.json();
          setTaxSavingsData(data.data);
        } else {
          const errorData = await response.json().catch(() => ({}));
          console.error('Failed to fetch tax savings data:', errorData.error || response.statusText);
          // Don't set error state - we'll use fallback calculations
        }
      } catch (error) {
        console.error('Error fetching tax savings:', error);
        // Don't set error state - we'll use fallback calculations
      } finally {
        setLoadingTaxSavings(false);
      }
    };

    fetchTaxSavings();
  }, [profile?.id]);

  if (!transactions) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse">
          <div className="w-8 h-8 bg-blue-200 rounded-full"></div>
        </div>
      </div>
    );
  }

  // Debug: Log first few transactions
  console.log('📋 Sample transactions:', transactions.slice(0, 3).map(t => ({
    id: t.id,
    merchant: t.merchant_name,
    amount: t.amount,
    amount_type: typeof t.amount,
    category: t.category,
    is_deductible: t.is_deductible,
    deduction_score: t.deduction_score,
    user_id: t.user_id
  })));

  // Use tax savings data from API if available, otherwise fall back to local calculations
  const taxSavings = taxSavingsData?.taxSavings?.yearToDate || 0;
  const projectedAnnualSavings = taxSavingsData?.taxSavings?.projectedAnnual || 0;
  const currentMonthDeductions = taxSavingsData?.deductions?.currentMonth || 0;
  const monthlyTargetPercentage = taxSavingsData?.deductions?.monthlyTargetPercentage || 0;

  let totalDeductions = 0;
  let uncategorizedCount = 0;

  // Calculate transactions that need review (uncategorized OR low confidence)
  const needsReviewCount = transactions.filter(t => {
    if (t.deduction_score === undefined || t.deduction_score === null) return false;
    return t.deduction_score >= 0.05 && t.deduction_score <= 0.75;
  }).length;

  // Calculate transactions that need AI analysis (default deduction_score of 0)
  const needsAnalysisCount = transactions.filter(t => 
    t.deduction_score === 0 && t.is_deductible === false
  ).length;

  // Calculate totals from transactions if API data not available
  if (!taxSavingsData) {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();

    for (let i = 0; i < transactions.length; i++) {
      const transaction = transactions[i];
      if (transaction && transaction.is_deductible === true && transaction.amount) {
        // Use savings_percentage to calculate actual deductible amount
        const deductibleAmount = transaction.amount * (transaction.savings_percentage || 100) / 100;
        totalDeductions += deductibleAmount;
      }
      
      if (transaction && ((transaction.deduction_score !== undefined && transaction.deduction_score !== null && transaction.deduction_score >= 0.05 && transaction.deduction_score <= 0.75))) {
        uncategorizedCount++;
      }
    }
  } else {
    totalDeductions = taxSavingsData.deductions.yearToDate;
    uncategorizedCount = needsReviewCount;
  }

  const categoryBreakdown: Record<string, number> = {};
  for (let i = 0; i < transactions.length; i++) {
    const transaction = transactions[i];
    if (transaction && transaction.is_deductible === true && transaction.category && transaction.amount) {
      // Use savings_percentage to calculate actual deductible amount
      const deductibleAmount = transaction.amount * (transaction.savings_percentage || 100) / 100;
      if (categoryBreakdown[transaction.category]) {
        categoryBreakdown[transaction.category] += deductibleAmount;
      } else {
        categoryBreakdown[transaction.category] = deductibleAmount;
      }
    }
  }

  const categoryEntries = [];
  for (const category in categoryBreakdown) {
    categoryEntries.push([category, categoryBreakdown[category]]);
  }
  
  categoryEntries.sort((a, b) => (b[1] as number) - (a[1] as number));
  const topCategories = categoryEntries.slice(0, 3);

  // Debug logging
  console.log('📊 Dashboard Data:', {
    profile: profile,
    totalTransactions: transactions.length,
    deductibleTransactions: transactions.filter(t => t.is_deductible === true).length,
    needsAnalysisCount,
    uncategorizedCount,
    taxSavingsData: taxSavingsData,
    categoryBreakdown,
    topCategories,
    totalDeductions
  });

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4 mb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
          <p className="text-gray-600">Welcome back, {profile?.name?.split(' ')[0] || 'there'}</p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => onNavigate('settings')} 
            className="w-8 h-8 lg:w-10 lg:h-10 rounded-lg flex items-center justify-center text-gray-600 hover:text-gray-800 hover:bg-gray-100 transition-colors"
          >
            <SettingsIcon />
          </button>
          {onSignOut && (
            <button 
              onClick={onSignOut} 
              className="w-8 h-8 lg:w-10 lg:h-10 rounded-lg flex items-center justify-center text-red-600 hover:text-red-700 hover:bg-red-50 transition-colors"
              title="Sign Out"
            >
              <LogOutIcon />
            </button>
          )}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6 mb-6">
        <button
          onClick={() => onNavigate('reports')}
          className="group bg-gradient-to-br from-emerald-50 to-green-50 border-2 border-emerald-200 hover:border-emerald-300 rounded-xl p-4 lg:p-5 text-left transition-all duration-200 shadow-md hover:shadow-lg sm:col-span-2 lg:col-span-2"
        >
          <div className="flex items-center gap-4 lg:gap-5 mb-4 lg:mb-5">
            <div className="w-12 h-12 lg:w-14 lg:h-14 bg-emerald-200 rounded-xl flex items-center justify-center text-emerald-700 shadow-sm">
              <DollarSignIcon />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-2xl lg:text-3xl font-bold text-emerald-800 mb-2">
                ${taxSavings.toFixed(0)}
              </div>
              <div className="text-sm lg:text-base font-bold text-emerald-700 uppercase tracking-wide">
                YTD Tax Savings
              </div>
            </div>
          </div>
          <div className="border-t border-emerald-200 pt-4">
            <p className="text-sm lg:text-base text-emerald-700 font-semibold mb-2">
              💰 Your money back in your pocket
            </p>
            <p className="text-xs lg:text-sm text-emerald-600">
              Projected: <span className="font-bold text-emerald-800">${projectedAnnualSavings.toFixed(0)}</span> annually
            </p>
          </div>
        </button>

        <button
          onClick={() => onNavigate('transactions')}
          className="group bg-white border border-gray-200 hover:border-blue-300 rounded-xl p-4 lg:p-5 text-left transition-all duration-200 shadow-sm hover:shadow-md"
        >
          <div className="flex items-center gap-3 lg:gap-4 mb-3 lg:mb-4">
            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600">
              <TrendingUpIcon />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xl lg:text-2xl font-semibold text-gray-900 mb-1">
                ${totalDeductions.toFixed(0)}
              </div>
              <div className="text-xs lg:text-sm font-bold text-gray-600 uppercase tracking-wide">
                Total Deductions
              </div>
            </div>
          </div>
          <div className="border-t border-gray-100 pt-3">
            <p className="text-xs lg:text-sm text-gray-600 font-medium mb-1">
              Total deductible expenses
            </p>
            <p className="text-xs text-gray-500">
              {transactions.filter(t => t.is_deductible === true).length} deductible transactions
            </p>
          </div>
        </button>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-4 lg:space-y-5">
          {/* Top Categories */}
          <div className="bg-white border border-gray-200 rounded-xl shadow-sm">
            <div className="p-4 lg:p-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4 lg:mb-6">
                <h3 className="text-base lg:text-lg font-bold text-gray-900">Top Deductible Categories</h3>
                <button 
                  onClick={() => onNavigate('categories')} 
                  className="text-blue-600 hover:text-blue-700 font-medium px-3 py-1.5 lg:px-4 lg:py-2 rounded-lg hover:bg-blue-50 text-sm transition-colors self-start sm:self-auto"
                >
                  View All
                </button>
              </div>
              
              <div>
                {topCategories.length > 0 ? (
                  <div className="space-y-3 lg:space-y-4">
                    {topCategories.map((categoryData) => {
                      const category = categoryData[0] as string;
                      const amount = categoryData[1] as number;
                      const percentage = totalDeductions > 0 ? (amount / totalDeductions) * 100 : 0;
                      const IconComponent = getCategoryIcon(category);
                      const categoryColor = getCategoryColor(category);
                      
                      return (
                        <div key={category} className="space-y-2">
                          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                            <div className="flex items-center gap-3">
                              <div className={`w-8 h-8 ${categoryColor.replace('bg-', 'bg-').replace('-500', '-100')} rounded-lg flex items-center justify-center`}>
                                <IconComponent />
                              </div>
                              <div>
                                <span className="font-medium text-gray-900 text-sm lg:text-base">{formatCategory(category)}</span>
                                <div className="text-xs text-gray-600">{percentage.toFixed(1)}% of your deductions</div>
                              </div>
                            </div>
                            <div className="text-right sm:text-left">
                              <span className="font-semibold text-gray-900 text-sm lg:text-base">${amount.toFixed(0)}</span>
                              <span className="text-xs lg:text-sm text-gray-600 ml-1 lg:ml-2">(${(amount * 0.3).toFixed(0)} saved)</span>
                            </div>
                          </div>
                          <div className="w-full bg-gray-100 rounded-full h-2">
                            <div 
                              className={`${categoryColor} h-2 rounded-full transition-all duration-500`}
                              style={{ width: `${Math.min(percentage, 100)}%` }}
                            ></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-6 lg:py-8 text-gray-600">
                    <div className="w-12 h-12 lg:w-16 lg:h-16 bg-gray-100 rounded-xl flex items-center justify-center mx-auto mb-3 lg:mb-4">
                      <BarChartIcon />
                    </div>
                    <p className="text-sm lg:text-base">
                      {transactions.length > 0 
                        ? `Found ${transactions.length} transactions. Run AI analysis to categorize them.`
                        : 'Start tracking expenses to see category breakdown'
                      }
                    </p>
                    {transactions.length > 0 && needsAnalysisCount > 0 && (
                      <p className="text-xs text-gray-500 mt-2">
                        {needsAnalysisCount} transactions need AI analysis
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* AI Analysis */}
          <div className="bg-gradient-to-br from-purple-50 to-indigo-50 border border-purple-200 rounded-xl shadow-sm">
            <div className="p-4 lg:p-5">
              <div className="flex items-center justify-between mb-4 lg:mb-6">
                <div className="flex items-center gap-2 lg:gap-3">
                  <div className="w-8 h-8 lg:w-10 lg:h-10 bg-purple-200 rounded-lg flex items-center justify-center shadow-sm">
                    <SparklesIcon />
                  </div>
                  <h3 className="text-base lg:text-lg font-bold text-purple-900">AI Analysis</h3>
                </div>
              </div>
              
              <div className="space-y-3">
                <button
                  onClick={async () => {
                    setIsAnalyzing(true);
                    setAnalysisResult(null);
                    setAnalysisProgress(null);
                    
                    try {
                      // Check if profile exists before proceeding
                      if (!profile || !profile.id) {
                        console.error('Profile or user_id not available');
                        setAnalysisResult({
                          analyzed: 0,
                          total: 0
                        });
                        return;
                      }

                      // Call the analysis API directly
                      const response = await makeAuthenticatedRequest('/api/openai/analyze-with-progress', {
                        method: 'POST',
                        body: JSON.stringify({ userId: profile.id }),
                      });

                      const result = await response.json();
                      
                      if (result.success) {
                        setAnalysisResult({
                          analyzed: result.analyzed,
                          total: result.total
                        });
                        
                        // Refresh transactions to show updated analysis
                        if (onAnalyzeTransactions) {
                          await onAnalyzeTransactions();
                        }
                      } else {
                        console.error('Analysis failed:', result.error);
                        setAnalysisResult({
                          analyzed: 0,
                          total: 0
                        });
                      }
                    } catch (error) {
                      console.error('Error during analysis:', error);
                      setAnalysisResult({
                        analyzed: 0,
                        total: 0
                      });
                    } finally {
                      setIsAnalyzing(false);
                    }
                  }}
                  disabled={isAnalyzing || !profile?.id}
                  className={`w-full h-14 rounded-xl border-2 transition-all duration-200 text-center group ${
                    isAnalyzing || !profile?.id
                      ? 'bg-gray-100 border-gray-300 text-gray-500 cursor-not-allowed' 
                      : 'bg-gradient-to-r from-purple-600 to-indigo-600 border-purple-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-md hover:shadow-lg'
                  }`}
                >
                  <div className="flex items-center justify-center gap-3 h-full px-4">
                    <div className="w-6 h-6 bg-white/20 rounded-lg flex items-center justify-center backdrop-blur-sm">
                      <SparklesIcon />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-base">
                        {!profile?.id ? 'Loading...' : 'Run AI Analysis'}
                      </div>
                      <p className="text-xs text-white/90">
                        {!profile?.id 
                          ? 'Please wait while we load your profile...' 
                          : needsAnalysisCount > 0 
                            ? `Analyze ${needsAnalysisCount} transactions with AI`
                            : uncategorizedCount > 0 
                              ? `Review ${uncategorizedCount} transactions`
                              : 'Optimize your tax deductions with AI'
                        }
                      </p>
                    </div>
                  </div>
                </button>

                {/* Manual Sync Button */}
                <button
                  onClick={async () => {
                    try {
                      // Call the sync transactions API
                      const response = await makeAuthenticatedRequest('/api/plaid/sync-transactions', {
                        method: 'POST',
                        body: JSON.stringify({ userId: profile.id }),
                      });

                      if (response.ok) {
                        const result = await response.json();
                        console.log('✅ Transactions synced successfully:', result);
                        // Show success message
                        alert(`✅ Synced ${result.transactionsSaved || 0} new transactions!`);
                        // Refresh transactions to show new data
                        if (onAnalyzeTransactions) {
                          await onAnalyzeTransactions();
                        }
                      } else {
                        console.error('❌ Failed to sync transactions');
                        alert('❌ Failed to sync transactions. Please try again.');
                      }
                    } catch (error) {
                      console.error('Error syncing transactions:', error);
                      alert('❌ Error syncing transactions. Please try again.');
                    } finally {
                      setIsSyncing(false);
                    }
                  }}
                  disabled={!profile?.id || isSyncing}
                  className={`w-full h-12 rounded-xl border-2 transition-all duration-200 text-center group ${
                    isSyncing 
                      ? 'border-blue-300 bg-blue-100 text-blue-600 cursor-not-allowed'
                      : 'border-blue-200 bg-blue-50 hover:bg-blue-100'
                  }`}
                >
                  <div className="flex items-center justify-center gap-3 h-full px-4">
                    <div className="w-5 h-5 bg-blue-200 rounded-lg flex items-center justify-center">
                      {isSyncing ? (
                        <div className="w-3 h-3 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                      ) : (
                        <RefreshCwIcon className="w-3 h-3 text-blue-600" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm text-blue-800">
                        {isSyncing ? 'Syncing...' : 'Sync New Transactions'}
                      </div>
                      <p className="text-xs text-blue-600">
                        {isSyncing ? 'Getting latest transactions...' : 'Get latest transactions from your bank'}
                      </p>
                    </div>
                  </div>
                </button>
                
                {/* Analysis Progress Popup */}
                {isAnalyzing && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 animate-in slide-in-from-top-2 duration-300">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 bg-blue-200 rounded-lg flex items-center justify-center flex-shrink-0">
                        <div className="w-4 h-4 border-2 border-blue-400 border-t-transparent rounded-full animate-spin"></div>
                      </div>
                      <div className="flex-1">
                        <div className="font-medium text-blue-800 mb-1">
                          Analyzing Transactions...
                        </div>
                        <p className="text-sm text-blue-700">
                          Processing transactions with AI analysis
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Analysis Result Popup */}
                {analysisResult && !isAnalyzing && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 animate-in slide-in-from-top-2 duration-300">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 bg-emerald-200 rounded-lg flex items-center justify-center flex-shrink-0">
                        <CheckCircleIcon />
                      </div>
                      <div className="flex-1">
                        <div className="font-medium text-emerald-800 mb-1">
                          Analysis Complete!
                        </div>
                        <p className="text-sm text-emerald-700">
                          Successfully analyzed {analysisResult.analyzed} out of {analysisResult.total} transactions
                        </p>
                      </div>
                      <button 
                        onClick={() => setAnalysisResult(null)}
                        className="text-emerald-600 hover:text-emerald-700 transition-colors"
                      >
                        ×
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white border border-gray-200 rounded-xl shadow-sm">
            <div className="p-4 lg:p-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4 lg:mb-6">
                <h3 className="text-base lg:text-lg font-bold text-gray-900">Recent Activity</h3>
                <button 
                  onClick={() => onNavigate('transactions')} 
                  className="text-blue-600 hover:text-blue-700 font-medium px-3 py-1.5 lg:px-4 lg:py-2 rounded-lg hover:bg-blue-50 text-sm transition-colors self-start sm:self-auto"
                >
                  View All
                </button>
              </div>
              
              <div className="space-y-3">
                {transactions.length > 0 ? (
                  transactions.slice(0, 5).map((transaction) => {
                  const isIncome = transaction.amount < 0;
                  const amount = Math.abs(transaction.amount);
                  
                  return (
                    <div 
                      key={transaction.id} 
                      className="flex flex-col sm:flex-row sm:items-center sm:justify-between py-2 px-3 hover:bg-gray-50 rounded-lg cursor-pointer group transition-colors gap-2"
                      onClick={() => onTransactionClick(transaction)}
                    >
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className={`w-2 h-2 lg:w-3 lg:h-3 rounded-full ${getCategoryColor(transaction.category)} flex-shrink-0`} />
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-gray-900 group-hover:text-blue-600 transition-colors text-sm lg:text-base truncate">
                            {transaction.merchant_name || transaction.description || 'Unknown Merchant'}
                          </div>
                          <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2 text-xs lg:text-sm text-gray-600">
                            <span>{isIncome ? 'Income' : formatCategory(transaction.category)}</span>
                            <span className="hidden sm:inline">•</span>
                            <span>{new Date(transaction.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                            <span className="hidden sm:inline">•</span>
                            <Badge 
                              variant={transaction.is_deductible === true ? "default" : "secondary"}
                              className={`text-xs ${transaction.is_deductible === true ? 'bg-green-100 text-green-700 border-green-200' : 'bg-red-100 text-red-700 border-red-200'}`}
                            >
                              {transaction.is_deductible === true ? 'Deductible' : 'Not Deductible'}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div className="text-right sm:text-left flex-shrink-0">
                        <div className={`font-semibold text-sm lg:text-base ${isIncome ? 'text-emerald-600' : 'text-gray-900'}`}>
                          {isIncome ? '+' : ''}${amount.toFixed(2)}
                        </div>
                        {transaction.is_deductible === true && !isIncome && transaction.savings_percentage !== undefined && transaction.savings_percentage > 0 && (
                          <div className="text-xs text-emerald-600">+${(amount * transaction.savings_percentage / 100 * 0.3).toFixed(2)} saved</div>
                        )}
                      </div>
                    </div>
                  );
                })
                ) : (
                  <div className="text-center py-8 text-gray-600">
                    <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                      <FileTextIcon />
                    </div>
                    <p className="text-sm">No transactions yet</p>
                    <p className="text-xs text-gray-500 mt-1">Connect your bank account to get started</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-4 lg:space-y-5">
          {/* Quick Actions */}
          <div className="bg-white border border-gray-200 rounded-xl shadow-sm p-4 lg:p-6">
            <h3 className="font-bold text-gray-900 mb-4 text-sm lg:text-base">Quick Actions</h3>
            <div className="grid grid-cols-2 sm:grid-cols-2 gap-3">
              {needsAnalysisCount > 0 && (
                <button 
                  onClick={() => onNavigate('review-transactions')} 
                  className="p-3 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-lg text-center transition-colors"
                >
                  <div className="w-8 h-8 bg-purple-200 rounded-lg flex items-center justify-center text-purple-700 mx-auto mb-2">
                    <SparklesIcon />
                  </div>
                  <div className="font-semibold text-gray-900 text-xs">AI Analysis</div>
                  <div className="text-xs text-gray-600">{needsAnalysisCount} pending</div>
                </button>
              )}
              
              {needsAnalysisCount === 0 && uncategorizedCount > 0 && (
                <button 
                  onClick={() => onNavigate('review-transactions')} 
                  className="p-3 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg text-center transition-colors"
                >
                  <div className="w-8 h-8 bg-amber-200 rounded-lg flex items-center justify-center text-amber-700 mx-auto mb-2">
                    <ClockIcon />
                  </div>
                  <div className="font-semibold text-gray-900 text-xs">Review</div>
                  <div className="text-xs text-gray-600">{uncategorizedCount} pending</div>
                </button>
              )}
              
              {uncategorizedCount === 0 && (
                <button 
                  onClick={() => onNavigate('transactions')} 
                  className="p-3 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg text-center transition-colors"
                >
                  <div className="w-8 h-8 bg-emerald-200 rounded-lg flex items-center justify-center text-emerald-700 mx-auto mb-2">
                    <CheckCircleIcon />
                  </div>
                  <div className="font-semibold text-gray-900 text-xs">All Caught Up</div>
                  <div className="text-xs text-gray-600">✓ Organized</div>
                </button>
              )}
              
              <button 
                onClick={() => onNavigate('add-receipt')} 
                className="p-3 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg text-center transition-colors"
              >
                <div className="w-8 h-8 bg-blue-200 rounded-lg flex items-center justify-center text-blue-700 mx-auto mb-2">
                  <CameraIcon />
                </div>
                <div className="font-semibold text-gray-900 text-xs">Add Receipt</div>
                <div className="text-xs text-gray-600">Upload</div>
              </button>

              <button 
                onClick={() => onNavigate('ai-insights')} 
                className="p-3 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-lg text-center transition-colors"
              >
                <div className="w-8 h-8 bg-purple-200 rounded-lg flex items-center justify-center text-purple-700 mx-auto mb-2">
                  <SparklesIcon />
                </div>
                <div className="font-semibold text-gray-900 text-xs">AI Insights</div>
                <div className="text-xs text-gray-600">Tips</div>
              </button>
              
              <button 
                onClick={() => onNavigate('transactions')} 
                className="p-3 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg text-center transition-colors"
              >
                <div className="w-8 h-8 bg-emerald-200 rounded-lg flex items-center justify-center text-emerald-700 mx-auto mb-2">
                  <FileTextIcon />
                </div>
                <div className="font-semibold text-gray-900 text-xs">Transactions</div>
                <div className="text-xs text-gray-600">View All</div>
              </button>
              
              <button 
                onClick={() => onNavigate('schedule-c-export')} 
                className="p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-center transition-colors"
              >
                <div className="w-8 h-8 bg-slate-200 rounded-lg flex items-center justify-center text-slate-700 mx-auto mb-2">
                  <FileTextIcon />
                </div>
                <div className="font-semibold text-gray-900 text-xs">Export</div>
                <div className="text-xs text-gray-600">Schedule C</div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}