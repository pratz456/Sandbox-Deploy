"use client";

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, CheckCircle, XCircle, AlertTriangle, HelpCircle, Info, ChevronRight, Tag } from 'lucide-react';
// Remove direct database import - we'll use API route instead

interface Transaction {
  id: string;
  merchant_name: string;
  amount: number;
  category: string;
  date: string;
  type?: 'expense' | 'income';
  is_deductible?: boolean | null;
  deductible_reason?: string;
  deduction_score?: number;
  description?: string;
  notes?: string;
  savings_percentage?: number;
  deduction_percent?: number;
}

interface ReviewTransactionsScreenProps {
  user: { id: string; email?: string; user_metadata?: { name?: string } };
  onBack: () => void;
  transactions: Transaction[];
  onTransactionUpdate: (updatedTransaction: Transaction) => void;
  onTransactionClick?: (transaction: Transaction) => void;
}

export const ReviewTransactionsScreen: React.FC<ReviewTransactionsScreenProps> = ({
  user,
  onBack,
  transactions,
  onTransactionUpdate,
  onTransactionClick
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [swipeDirection, setSwipeDirection] = useState<'left' | 'right' | null>(null);
  const [touchStart, setTouchStart] = useState<{ x: number; y: number } | null>(null);
  const [touchOffset, setTouchOffset] = useState(0);

  // Needs review = AI confidence between 20% and 75% and not yet user classified (is_deductible still null)
  const needsReviewTransactions = transactions.filter(t => {
    if (t.deduction_score === undefined || t.deduction_score === null) return false;
    return t.deduction_score >= 0.05 && t.deduction_score <= 0.75;
  });

  const currentTransaction = needsReviewTransactions[currentIndex];

  const handleSwipe = (direction: 'left' | 'right') => {
    if (!currentTransaction || isProcessing) return;
    
    setSwipeDirection(direction);
    const isDeductible = direction === 'right';
    handleClassification(currentTransaction, isDeductible);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    setTouchStart({ x: touch.clientX, y: touch.clientY });
    setTouchOffset(0);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!touchStart) return;
    
    const touch = e.touches[0];
    const deltaX = touch.clientX - touchStart.x;
    const deltaY = Math.abs(touch.clientY - touchStart.y);
    
    // Only track horizontal swipes
    if (deltaY < 50) {
      setTouchOffset(deltaX);
    }
  };

  const handleTouchEnd = () => {
    if (!touchStart || !currentTransaction) {
      setTouchStart(null);
      setTouchOffset(0);
      return;
    }
    
    const threshold = 100; // Minimum distance for a swipe
    
    if (Math.abs(touchOffset) > threshold) {
      if (touchOffset < 0) {
        handleSwipe('left'); // Swipe left = Personal
      } else {
        handleSwipe('right'); // Swipe right = Deductible
      }
    }
    
    setTouchStart(null);
    setTouchOffset(0);
  };

  const handleClassification = async (transaction: Transaction, isDeductible: boolean) => {
    if (isProcessing) return;
    setIsProcessing(true);

    console.log('🎯 [UI RERENDER] Starting classification for transaction:', transaction.id, 'isDeductible:', isDeductible);
    console.log('🎯 [UI RERENDER] Full transaction object:', transaction);

    try {
      const updateData = {
        is_deductible: isDeductible,
        deductible_reason: isDeductible 
          ? 'Classified as business expense by user'
          : 'Classified as personal expense by user',
        deduction_score: isDeductible ? 1.0 : 0.0
      };

      console.log('📝 [UI RERENDER] Calling API to update transaction with:', updateData);
      
      const response = await fetch(`/api/transactions/${transaction.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updateData),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        console.error('❌ [UI RERENDER] API update failed:', result);
        return;
      }

      console.log('✅ [UI RERENDER] API update successful:', result.transaction);

      // Update the transaction in the parent state
      const updated: Transaction = {
        ...transaction,
        is_deductible: isDeductible,
        deductible_reason: updateData.deductible_reason,
        deduction_score: updateData.deduction_score
      };
      
      console.log('🔄 [UI RERENDER] Updating parent state with:', updated.id, updated.is_deductible);
      onTransactionUpdate(updated);

      // Move to next transaction after a brief delay
      setTimeout(() => {
        if (currentIndex < needsReviewTransactions.length - 1) {
          setCurrentIndex(prev => prev + 1);
        }
        setSwipeDirection(null);
      }, 800);

    } catch (e: any) {
      console.error('❌ [UI RERENDER] Unexpected update error:', e);
    } finally {
      setIsProcessing(false);
    }
  };

  const formatCategory = (category: string): string => {
    if (!category) return 'Uncategorized';
    return category
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' & ');
  };

  if (needsReviewTransactions.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-emerald-600" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">All caught up!</h3>
          <p className="text-gray-600 mb-6">No transactions need review at this time.</p>
          <Button onClick={onBack} className="flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  if (currentIndex >= needsReviewTransactions.length) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-emerald-600" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Review Complete!</h3>
          <p className="text-gray-600 mb-6">You've reviewed all transactions that needed attention.</p>
          <Button onClick={onBack} className="flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4">
        {/* Sticky Header */}
        <div className="sticky top-0 bg-gray-50 z-10 py-4">
          <div className="flex items-center justify-between mb-4">
            <button 
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label="Go back"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            
            <div className="text-center">
              <h1 className="text-lg font-semibold text-gray-900">Review Transactions</h1>
              <p className="text-xs text-slate-500">{needsReviewTransactions.length - currentIndex} to review</p>
            </div>
            
            <div className="w-9 h-9" /> {/* Spacer for alignment */}
          </div>
          
          <div className="border-b border-slate-200 mb-4" />
          
          <p className="text-center text-xs text-slate-600">
            Swipe right to deduct • Swipe left to skip • Tap for details
          </p>
        </div>

        {/* Main Card */}
        <div className="pb-6">
          <div
            className={`rounded-2xl border border-slate-200 bg-white shadow-sm transition-all duration-300 ${
              swipeDirection === 'right' ? 'transform translate-x-8 opacity-80 bg-green-50' :
              swipeDirection === 'left' ? 'transform -translate-x-8 opacity-80 bg-red-50' :
              isProcessing ? 'scale-[0.98]' : ''
            }`}
            style={{
              transform: `translateX(${Math.max(-150, Math.min(150, touchOffset))}px)`,
              opacity: Math.abs(touchOffset) > 50 ? 0.8 : 1
            }}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            <div className="p-5 sm:p-6">
              {/* Title Row */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1 min-w-0">
                  <h2 className="text-lg font-semibold text-gray-900 truncate">
                    {currentTransaction.merchant_name}
                  </h2>
                  <p className="text-xs text-slate-500 mt-1">
                    {new Date(currentTransaction.date).toLocaleDateString('en-US', { 
                      month: 'short', 
                      day: 'numeric' 
                    })}
                  </p>
                </div>
                <div className="text-xl font-semibold text-gray-900">
                  ${Math.abs(currentTransaction.amount).toFixed(2)}
                </div>
              </div>

              {/* View Details Button */}
              <button
                onClick={() => onTransactionClick?.(currentTransaction)}
                className="w-full flex items-center justify-between p-3 border bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
                aria-label="View transaction details"
              >
                <div className="flex items-center gap-2">
                  <Info className="w-4 h-4 text-slate-500" />
                  <span className="text-sm font-medium text-slate-700">View Details</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              {/* Category Pill */}
              <div className="mb-4">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-blue-50 text-blue-700 border border-blue-100 rounded-full text-xs font-medium">
                  <Tag className="w-3 h-3" />
                  {formatCategory(currentTransaction.category)}
                </div>
              </div>

              {/* Description Section */}
              <div className="mb-4">
                <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wide mb-2">
                  DESCRIPTION
                </div>
                <p className="text-sm text-slate-800">
                  {currentTransaction.description || currentTransaction.deductible_reason || 'No additional details available'}
                </p>
              </div>

              {/* AI Analysis Section */}
              <div className="mb-6">
                <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wide mb-2">
                  AI ANALYSIS
                </div>
                <p className="text-sm text-slate-800">
                  {currentTransaction.deductible_reason || `${formatCategory(currentTransaction.category)} at ${currentTransaction.merchant_name} are commonly deductible for freelancer/creator businesses. Keep detailed records of services provided and business purpose.`}
                </p>
              </div>
            </div>

            {/* Bottom Rail */}
            <div className="border-t border-slate-200 p-5 sm:p-6">
              <div className="flex items-center justify-between">
                <button
                  onClick={() => handleSwipe('left')}
                  disabled={isProcessing}
                  className="flex items-center gap-2 text-rose-600 hover:text-rose-700 transition-colors focus:outline-none focus:ring-2 focus:ring-rose-500 focus:ring-offset-2 rounded-lg p-2 min-h-[40px] disabled:opacity-50"
                  aria-label="Mark as personal expense"
                >
                  <XCircle className="w-5 h-5" />
                  <span className="font-medium">Personal</span>
                </button>
                
                <button
                  onClick={() => handleSwipe('right')}
                  disabled={isProcessing}
                  className="flex items-center gap-2 text-green-600 hover:text-green-700 transition-colors focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 rounded-lg p-2 min-h-[40px] disabled:opacity-50"
                  aria-label="Mark as deductible expense"
                >
                  <CheckCircle className="w-5 h-5" />
                  <span className="font-medium">Deductible</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
