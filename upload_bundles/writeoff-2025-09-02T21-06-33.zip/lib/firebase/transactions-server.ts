import { adminDb } from "./admin";

export interface Transaction {
  id: string;
  trans_id: string;
  merchant_name: string;
  amount: number;
  category: string;
  date: string;
  type?: 'expense' | 'income';
  is_deductible?: boolean | null;
  deductible_reason?: string;
  deduction_score?: number;
  description?: string;
  notes?: string;
  savings_percentage?: number;
  deduction_percent?: number;
  estimated_deduction_percent?: number;
  account_id?: string;
  user_id?: string;
  created_at?: any;
  updated_at?: any;
}

// Server-side function (for use in API routes)
export async function getTransactionsServer(
  userId: string, 
  fields?: string[]
): Promise<{ data: Transaction[]; error: any }> {
  try {
    console.log('🔍 [Firebase Server] Fetching transactions for user:', userId);
    if (fields) {
      console.log('📋 [Firebase Server] Requested fields:', fields);
    }
    
    let allTransactions: Transaction[] = [];
    
    try {
      // Use collectionGroup query to get all transactions for this user
      const transactionsQuery = adminDb.collectionGroup('transactions')
        .where('user_id', '==', userId);
      
            const querySnapshot = await transactionsQuery.get();
      console.log(`📊 [Firebase Server] Found ${querySnapshot.size} transactions for user ${userId}`);
    
    querySnapshot.forEach((doc) => {
      const data = doc.data();
      console.log('🔍 [Firebase Server] Processing transaction:', {
        id: data.trans_id || doc.id,
        merchant: data.merchant_name,
        category: data.category,
        is_deductible: data.is_deductible,
        is_deductible_type: typeof data.is_deductible,
      });
      
              allTransactions.push({
          id: data.trans_id || doc.id,
          trans_id: data.trans_id || doc.id,
          merchant_name: data.merchant_name || '',
          amount: data.amount || 0,
          category: data.category || '',
          date: data.date || '',
          type: data.amount < 0 ? 'income' : 'expense',
          is_deductible: data.is_deductible,
          deductible_reason: data.deductible_reason,
          deduction_score: data.deduction_score,
          description: data.description,
          notes: data.notes,
          savings_percentage: data.savings_percentage,
          deduction_percent: data.deduction_percent,
          estimated_deduction_percent: data.estimated_deduction_percent,
          account_id: data.account_id,
          user_id: data.user_id,
          created_at: data.created_at,
          updated_at: data.updated_at,
        });
    });
    
      // Sort transactions by date in descending order
      allTransactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      
      console.log('✅ [Firebase Server] Successfully processed', allTransactions.length, 'transactions');
      return { data: allTransactions, error: null };
    } catch (collectionGroupError: any) {
      console.warn('⚠️ [Firebase Server] CollectionGroup query failed, trying fallback method:', collectionGroupError);
      
      // Fallback: Try to get transactions from individual accounts
      try {
        const accountsSnapshot = await adminDb.collection('user_profiles').doc(userId).collection('accounts').get();
        console.log(`📊 [Firebase Server] Found ${accountsSnapshot.size} accounts for user ${userId}`);
        
        for (const accountDoc of accountsSnapshot.docs) {
          const transactionsSnapshot = await adminDb.collection('user_profiles').doc(userId)
            .collection('accounts').doc(accountDoc.id)
            .collection('transactions').get();
          
          console.log(`📊 [Firebase Server] Found ${transactionsSnapshot.size} transactions for account ${accountDoc.id}`);
          
          transactionsSnapshot.forEach((doc) => {
            const data = doc.data();
            allTransactions.push({
              id: data.trans_id || doc.id,
              trans_id: data.trans_id || doc.id,
              merchant_name: data.merchant_name || '',
              amount: data.amount || 0,
              category: data.category || '',
              date: data.date || '',
              type: data.amount < 0 ? 'income' : 'expense',
              is_deductible: data.is_deductible,
              deductible_reason: data.deductible_reason,
              deduction_score: data.deduction_score,
              description: data.description,
              notes: data.notes,
              savings_percentage: data.savings_percentage,
              deduction_percent: data.deduction_percent,
              estimated_deduction_percent: data.estimated_deduction_percent,
              account_id: data.account_id,
              user_id: data.user_id,
              created_at: data.created_at,
              updated_at: data.updated_at,
            });
          });
        }
        
        // Sort transactions by date in descending order
        allTransactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        
        console.log('✅ [Firebase Server] Successfully processed', allTransactions.length, 'transactions using fallback method');
        return { data: allTransactions, error: null };
      } catch (fallbackError: any) {
        console.error('❌ [Firebase Server] Fallback method also failed:', fallbackError);
        throw fallbackError;
      }
    }
  } catch (error: any) {
    console.error('❌ [Firebase Server] Error getting transactions:', error);
    
    // Handle specific Firebase errors
    if (error.code === 'permission-denied') {
      console.error('❌ [Firebase Server] Permission denied - check Firestore rules');
      return { data: [], error: { code: 'permission-denied', message: 'Permission denied. Check Firestore security rules.' } };
    } else if (error.code === 'unavailable') {
      console.error('❌ [Firebase Server] Firebase service unavailable');
      return { data: [], error: { code: 'unavailable', message: 'Database service temporarily unavailable.' } };
    } else if (error.code === 'failed-precondition') {
      console.error('❌ [Firebase Server] Query failed precondition - likely missing index');
      return { data: [], error: { code: 'failed-precondition', message: 'Database query failed. Missing required index.' } };
    }
    
    return { data: [], error };
  }
}

// Server-side function (for use in API routes) - with userId for efficiency
export async function updateTransactionServerWithUserId(
  userId: string,
  transactionId: string,
  updates: {
    is_deductible?: boolean | null;
    deductible_reason?: string;
    deduction_score?: number;
    notes?: string;
  }
): Promise<{ data: any; error: any }> {
  try {
    console.log('🔄 [UPDATE→DB Server] Updating transaction with userId:', userId, transactionId, updates);
    
    // Strategy 1: Try collectionGroup query first (more efficient with userId filter)
    try {
      console.log('🔍 [UPDATE→DB Server] Attempting collectionGroup query with userId filter...');
      const transactionsQuery = adminDb.collectionGroup('transactions')
        .where('user_id', '==', userId)
        .where('trans_id', '==', transactionId)
        .limit(1);
      
      const querySnapshot = await transactionsQuery.get();
      
      if (!querySnapshot.empty) {
        console.log('✅ [UPDATE→DB Server] Found transaction via collectionGroup query');
        const docRef = querySnapshot.docs[0].ref;
        const updateData = {
          ...updates,
          updated_at: new Date(),
        };
        
        console.log('📝 [UPDATE→DB Server] Updating document at path:', docRef.path);
        await docRef.update(updateData);
        
        // Read back to verify the update
        const updatedDoc = await docRef.get();
        if (updatedDoc.exists) {
          const data = updatedDoc.data();
          console.log('✅ [READBACK←DB Server] Update verified:', {
            trans_id: data?.trans_id,
            is_deductible: data?.is_deductible,
            deductible_reason: data?.deductible_reason,
            deduction_score: data?.deduction_score
          });
          return { data: [data], error: null };
        }
        
        return { data: null, error: new Error('Failed to verify update') };
      }
      
      console.log('⚠️ [UPDATE→DB Server] No transaction found via collectionGroup query, trying fallback...');
    } catch (collectionGroupError: any) {
      console.warn('⚠️ [UPDATE→DB Server] CollectionGroup query failed:', collectionGroupError);
      console.warn('⚠️ [UPDATE→DB Server] Error code:', collectionGroupError.code);
      console.warn('⚠️ [UPDATE→DB Server] Error message:', collectionGroupError.message);
      
      // If it's a FAILED_PRECONDITION, it's likely a missing index
      if (collectionGroupError.code === 9 || collectionGroupError.code === 'FAILED_PRECONDITION') {
        console.log('🔧 [UPDATE→DB Server] FAILED_PRECONDITION detected - likely missing index, using fallback method');
      }
    }
    
    // Strategy 2: Fallback - search through user's accounts only
    console.log('🔄 [UPDATE→DB Server] Using fallback method - searching through user accounts...');
    
    try {
      // Get all accounts for this specific user
      const accountsSnapshot = await adminDb.collection('user_profiles').doc(userId).collection('accounts').get();
      console.log(`🔍 [UPDATE→DB Server] Found ${accountsSnapshot.size} accounts for user ${userId}`);
      
      for (const accountDoc of accountsSnapshot.docs) {
        const accountId = accountDoc.id;
        console.log(`🔍 [UPDATE→DB Server] Checking account: ${accountId}`);
        
        // Get all transactions for this account
        const transactionsSnapshot = await adminDb.collection('user_profiles').doc(userId)
          .collection('accounts').doc(accountId)
          .collection('transactions').get();
        
        console.log(`🔍 [UPDATE→DB Server] Found ${transactionsSnapshot.size} transactions for account ${accountId}`);
        
        // Find the specific transaction
        const targetTransaction = transactionsSnapshot.docs.find(doc => {
          const data = doc.data();
          return data.trans_id === transactionId;
        });
        
        if (targetTransaction) {
          console.log('✅ [UPDATE→DB Server] Found transaction via fallback method');
          const docRef = targetTransaction.ref;
          const updateData = {
            ...updates,
            updated_at: new Date(),
          };
          
          console.log('📝 [UPDATE→DB Server] Updating document at path:', docRef.path);
          await docRef.update(updateData);
          
          // Read back to verify the update
          const updatedDoc = await docRef.get();
          if (updatedDoc.exists) {
            const data = updatedDoc.data();
            console.log('✅ [READBACK←DB Server] Update verified:', {
              trans_id: data?.trans_id,
              is_deductible: data?.is_deductible,
              deductible_reason: data?.deductible_reason,
              deduction_score: data?.deduction_score
            });
            return { data: [data], error: null };
          }
          
          return { data: null, error: new Error('Failed to verify update') };
        }
      }
      
      console.error('❌ [UPDATE→DB Server] Transaction not found in user accounts');
      return { data: null, error: new Error('Transaction not found') };
      
    } catch (fallbackError: any) {
      console.error('❌ [UPDATE→DB Server] Fallback method failed:', fallbackError);
      console.error('❌ [UPDATE→DB Server] Fallback error code:', fallbackError.code);
      console.error('❌ [UPDATE→DB Server] Fallback error message:', fallbackError.message);
      throw fallbackError;
    }
    
  } catch (error: any) {
    console.error('❌ [UPDATE→DB Server] Update failed:', error);
    console.error('❌ [UPDATE→DB Server] Error type:', typeof error);
    console.error('❌ [UPDATE→DB Server] Error code:', error.code);
    console.error('❌ [UPDATE→DB Server] Error message:', error.message);
    
    // Handle specific Firebase errors
    if (error.code === 9 || error.code === 'FAILED_PRECONDITION') {
      console.error('❌ [UPDATE→DB Server] FAILED_PRECONDITION - This could be due to:');
      console.error('   - Missing composite index for collectionGroup query');
      console.error('   - Security rules preventing the operation');
      console.error('   - Invalid query structure');
      return { 
        data: null, 
        error: { 
          code: 'FAILED_PRECONDITION', 
          message: 'Database operation failed. This may be due to missing indexes or security rules.',
          details: error.message 
        } 
      };
    } else if (error.code === 'permission-denied') {
      console.error('❌ [UPDATE→DB Server] Permission denied - check Firestore rules');
      return { 
        data: null, 
        error: { 
          code: 'permission-denied', 
          message: 'Permission denied. Check Firestore security rules.',
          details: error.message 
        } 
      };
    } else if (error.code === 'unavailable') {
      console.error('❌ [UPDATE→DB Server] Firebase service unavailable');
      return { 
        data: null, 
        error: { 
          code: 'unavailable', 
          message: 'Database service temporarily unavailable.',
          details: error.message 
        } 
      };
    }
    
    return { data: null, error };
  }
}

// Server-side function (for use in API routes)
export async function createTransactionServer(
  userId: string,
  accountId: string,
  transactionData: Partial<Transaction>
): Promise<{ data: Transaction | null; error: any }> {
  try {
    const transId = transactionData.trans_id || `trans_${Date.now()}`;
    const docRef = adminDb.collection("user_profiles").doc(userId).collection("accounts").doc(accountId).collection("transactions").doc(transId);
    
    const newTransaction = {
      ...transactionData,
      trans_id: transId,
      user_id: userId,
      account_id: accountId,
      created_at: new Date(),
      updated_at: new Date(),
    };
    
    await docRef.set(newTransaction);
    
    // Return the created transaction
    const createdDoc = await docRef.get();
    if (createdDoc.exists) {
      const data = createdDoc.data();
              return {
          data: {
            id: data.trans_id || createdDoc.id,
            trans_id: data.trans_id || createdDoc.id,
            merchant_name: data.merchant_name || '',
            amount: data.amount || 0,
            category: data.category || '',
            date: data.date || '',
            type: data.amount < 0 ? 'income' : 'expense',
            is_deductible: data.is_deductible,
            deductible_reason: data.deductible_reason,
            deduction_score: data.deduction_score,
            description: data.description,
            notes: data.notes,
            savings_percentage: data.savings_percentage,
            account_id: data.account_id,
            user_id: data.user_id,
            created_at: data.created_at,
            updated_at: data.updated_at,
          },
          error: null
        };
    }
    
    return { data: null, error: new Error('Failed to retrieve created transaction') };
  } catch (error) {
    console.error('Error creating transaction (server):', error);
    return { data: null, error };
  }
}
