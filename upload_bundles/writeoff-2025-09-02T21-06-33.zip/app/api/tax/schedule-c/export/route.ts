import { NextRequest, NextResponse } from 'next/server';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';
import { getAuthenticatedUser } from '@/lib/firebase/api-auth';
import { getTransactionsServer } from '@/lib/firebase/transactions-server';

// Category mapping to Schedule C line items
const CATEGORY_MAP: { [key: string]: { line: string; lineName: string; lineCode: string } } = {
  // Meals - 50% deductible
  'FOOD_AND_DRINK_COFFEE_SHOP': { line: 'Meals', lineName: 'Meals and Entertainment', lineCode: '24b' },
  'FOOD_AND_DRINK_FAST_FOOD': { line: 'Meals', lineName: 'Meals and Entertainment', lineCode: '24b' },
  'FOOD_AND_DRINK_RESTAURANT': { line: 'Meals', lineName: 'Meals and Entertainment', lineCode: '24b' },
  'FOOD_AND_DRINK_ALCOHOL_AND_BARS': { line: 'Meals', lineName: 'Meals and Entertainment', lineCode: '24b' },

  // Office expense
  'GENERAL_MERCHANDISE_OFFICE_SUPPLIES': { line: 'Office', lineName: 'Office Expense', lineCode: '18' },
  'GENERAL_MERCHANDISE_COMPUTERS_AND_ELECTRONICS': { line: 'Office', lineName: 'Office Expense', lineCode: '18' },
  'GENERAL_MERCHANDISE_HOME_IMPROVEMENT': { line: 'Office', lineName: 'Office Expense', lineCode: '18' },
  'GENERAL_MERCHANDISE_PHARMACY': { line: 'Office', lineName: 'Office Expense', lineCode: '18' },
  'GENERAL_MERCHANDISE_OTHER_GENERAL_MERCHANDISE': { line: 'Office', lineName: 'Office Expense', lineCode: '18' },
  'SERVICE_SHIPPING': { line: 'Office', lineName: 'Office Expense', lineCode: '18' },
  'SERVICE_UTILITIES': { line: 'Office', lineName: 'Office Expense', lineCode: '18' },
  'SERVICE_STORAGE': { line: 'Office', lineName: 'Office Expense', lineCode: '18' },

  // Professional services
  'SERVICE_ACCOUNTING': { line: 'Professional', lineName: 'Legal and Professional Services', lineCode: '17' },
  'SERVICE_CONSULTING': { line: 'Professional', lineName: 'Legal and Professional Services', lineCode: '17' },
  'SERVICE_LEGAL': { line: 'Professional', lineName: 'Legal and Professional Services', lineCode: '17' },
  'SERVICE_MARKETING': { line: 'Professional', lineName: 'Legal and Professional Services', lineCode: '17' },
  'SERVICE_ADVERTISING': { line: 'Professional', lineName: 'Legal and Professional Services', lineCode: '17' },
  'SERVICE_SECURITY': { line: 'Professional', lineName: 'Legal and Professional Services', lineCode: '17' },
  'SERVICE_INSURANCE': { line: 'Professional', lineName: 'Legal and Professional Services', lineCode: '17' },

  // Car and truck expenses
  'TRANSPORTATION_RIDESHARE': { line: 'Vehicle', lineName: 'Car and Truck Expenses', lineCode: '9' },
  'TRANSPORTATION_AUTO_PARKING': { line: 'Vehicle', lineName: 'Car and Truck Expenses', lineCode: '9' },
  'TRANSPORTATION_AUTO_REPAIR': { line: 'Vehicle', lineName: 'Car and Truck Expenses', lineCode: '9' },
  'TRANSPORTATION_AUTO_SERVICE': { line: 'Vehicle', lineName: 'Car and Truck Expenses', lineCode: '9' },
  'TRANSPORTATION_FUEL': { line: 'Vehicle', lineName: 'Car and Truck Expenses', lineCode: '9' },
  'TRANSPORTATION_TOLLS': { line: 'Vehicle', lineName: 'Car and Truck Expenses', lineCode: '9' },
  'TRANSPORTATION_AUTO_INSURANCE': { line: 'Vehicle', lineName: 'Car and Truck Expenses', lineCode: '9' },

  // Travel
  'TRAVEL_FLIGHTS': { line: 'Travel', lineName: 'Travel, Meals, and Lodging', lineCode: '24a' },
  'TRAVEL_LODGING': { line: 'Travel', lineName: 'Travel, Meals, and Lodging', lineCode: '24a' },
  'TRAVEL_OTHER_TRAVEL': { line: 'Travel', lineName: 'Travel, Meals, and Lodging', lineCode: '24a' },

  // Other expenses
  'ENTERTAINMENT_SPORTS_AND_OUTDOORS': { line: 'Other', lineName: 'Other Expenses', lineCode: '27a' },
  'ENTERTAINMENT_ARTS': { line: 'Other', lineName: 'Other Expenses', lineCode: '27a' },
  'ENTERTAINMENT_THEATER': { line: 'Other', lineName: 'Other Expenses', lineCode: '27a' },
  'ENTERTAINMENT_MUSIC': { line: 'Other', lineName: 'Other Expenses', lineCode: '27a' },
  'ENTERTAINMENT_MOVIES_AND_DVDS': { line: 'Other', lineName: 'Other Expenses', lineCode: '27a' },
  'GENERAL_MERCHANDISE_SPORTING_GOODS': { line: 'Other', lineName: 'Other Expenses', lineCode: '27a' },
  'PERSONAL_CARE_GYMS_AND_FITNESS_CENTERS': { line: 'Other', lineName: 'Other Expenses', lineCode: '27a' },
  'COMMUNITY_CHARITY': { line: 'Other', lineName: 'Other Expenses', lineCode: '27a' },
  'COMMUNITY_EDUCATION': { line: 'Other', lineName: 'Other Expenses', lineCode: '27a' },
  'COMMUNITY_RELIGIOUS': { line: 'Other', lineName: 'Other Expenses', lineCode: '27a' },
};

interface Transaction {
  id: string;
  trans_id?: string;
  merchant_name: string;
  amount: number;
  category: string;
  date: string;
  type?: 'expense' | 'income';
  is_deductible?: boolean | null;
  deductible_reason?: string;
  deduction_score?: number;
  description?: string;
  notes?: string;
}

interface ScheduleCLineItem {
  lineCode: string;
  lineName: string;
  total: number;
  deductible: number;
  transactionCount: number;
  transactions: Transaction[];
}

export async function POST(request: NextRequest) {
  try {
    // Get the authenticated user
    const { user, error: authError } = await getAuthenticatedUser(request);
    
    if (authError || !user) {
      console.error('❌ [Schedule C Export] Authentication failed:', authError);
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { year } = body;

    if (!year) {
      return NextResponse.json({ error: 'Year is required' }, { status: 400 });
    }

    console.log('✅ [Schedule C Export] User authenticated:', user.uid, 'Year:', year);

    // Fetch all transactions for the user
    const { data: allTransactions, error } = await getTransactionsServer(user.uid);
    
    if (error) {
      console.error('❌ [Schedule C Export] Error fetching transactions:', error);
      return NextResponse.json({ error: 'Failed to fetch transactions' }, { status: 500 });
    }

    // Filter transactions for the specified year
    const yearTransactions = (allTransactions || []).filter((t: Transaction) => {
      const transactionYear = new Date(t.date).getFullYear().toString();
      return transactionYear === year;
    });

    console.log('🔍 [Schedule C Export] Year transactions:', {
      year,
      totalTransactions: allTransactions?.length || 0,
      yearTransactions: yearTransactions.length
    });

    // Get reviewed transactions (confirmed deductible)
    const reviewedTransactions = yearTransactions.filter((t: Transaction) => 
      t.is_deductible === true && t.amount > 0
    );

    // Get potentially deductible transactions (business categories not yet reviewed)
    const potentialTransactions = yearTransactions.filter((t: Transaction) => 
      (t.is_deductible === null || t.is_deductible === undefined) &&
      Object.keys(CATEGORY_MAP).includes(t.category) &&
      t.amount > 0
    );

    // Combine all deductible transactions
    const allDeductibleTransactions = [...reviewedTransactions, ...potentialTransactions];

    console.log('🔍 [Schedule C Export] Deductible transactions:', {
      reviewed: reviewedTransactions.length,
      potential: potentialTransactions.length,
      total: allDeductibleTransactions.length
    });

    // Aggregate totals per Schedule C line item
    const lineItems: { [key: string]: ScheduleCLineItem } = {};

    allDeductibleTransactions.forEach((transaction: Transaction) => {
      const categoryInfo = CATEGORY_MAP[transaction.category];
      const lineKey = categoryInfo ? categoryInfo.line : 'Other';
      
      if (!lineItems[lineKey]) {
        lineItems[lineKey] = {
          lineCode: categoryInfo?.lineCode || '27a',
          lineName: categoryInfo?.lineName || 'Other Expenses',
          total: 0,
          deductible: 0,
          transactionCount: 0,
          transactions: []
        };
      }

      const amount = Math.abs(transaction.amount);
      lineItems[lineKey].total += amount;
      lineItems[lineKey].transactionCount += 1;
      lineItems[lineKey].transactions.push(transaction);

      // Apply 50% rule for meals
      if (lineKey === 'Meals') {
        lineItems[lineKey].deductible += amount * 0.5;
      } else {
        lineItems[lineKey].deductible += amount;
      }
    });

    // Convert to array and sort by line code
    const sortedLineItems = Object.values(lineItems).sort((a, b) => {
      const aNum = parseInt(a.lineCode.replace(/\D/g, ''));
      const bNum = parseInt(b.lineCode.replace(/\D/g, ''));
      return aNum - bNum;
    });

    // Calculate totals
    const totalExpenses = sortedLineItems.reduce((sum, item) => sum + item.total, 0);
    const totalDeductible = sortedLineItems.reduce((sum, item) => sum + item.deductible, 0);

    // Generate PDF
    const pdfDoc = await PDFDocument.create();
    const page = pdfDoc.addPage([612, 792]); // Standard US Letter size
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

    let yPosition = 750;

    // Header
    page.drawText(`Schedule C Summary - Tax Year ${year}`, {
      x: 50,
      y: yPosition,
      size: 18,
      font: boldFont,
      color: rgb(0, 0, 0)
    });
    yPosition -= 30;

    page.drawText(`Generated on: ${new Date().toLocaleDateString()}`, {
      x: 50,
      y: yPosition,
      size: 10,
      font: font,
      color: rgb(0.5, 0.5, 0.5)
    });
    yPosition -= 40;

    // Summary table
    page.drawText('Schedule C Line Items Summary', {
      x: 50,
      y: yPosition,
      size: 14,
      font: boldFont,
      color: rgb(0, 0, 0)
    });
    yPosition -= 30;

    // Table headers
    const headers = ['Line', 'Description', 'Total Amount', 'Deductible Amount', 'Transactions'];
    const columnWidths = [60, 200, 100, 100, 80];
    let xPosition = 50;

    headers.forEach((header, index) => {
      page.drawText(header, {
        x: xPosition,
        y: yPosition,
        size: 10,
        font: boldFont,
        color: rgb(0, 0, 0)
      });
      xPosition += columnWidths[index];
    });
    yPosition -= 20;

    // Table rows
    sortedLineItems.forEach((item) => {
      xPosition = 50;
      
      // Line code
      page.drawText(item.lineCode, {
        x: xPosition,
        y: yPosition,
        size: 10,
        font: font,
        color: rgb(0, 0, 0)
      });
      xPosition += columnWidths[0];

      // Description
      page.drawText(item.lineName, {
        x: xPosition,
        y: yPosition,
        size: 10,
        font: font,
        color: rgb(0, 0, 0)
      });
      xPosition += columnWidths[1];

      // Total amount
      page.drawText(`$${item.total.toFixed(2)}`, {
        x: xPosition,
        y: yPosition,
        size: 10,
        font: font,
        color: rgb(0, 0, 0)
      });
      xPosition += columnWidths[2];

      // Deductible amount
      page.drawText(`$${item.deductible.toFixed(2)}`, {
        x: xPosition,
        y: yPosition,
        size: 10,
        font: font,
        color: rgb(0, 0, 0)
      });
      xPosition += columnWidths[3];

      // Transaction count
      page.drawText(item.transactionCount.toString(), {
        x: xPosition,
        y: yPosition,
        size: 10,
        font: font,
        color: rgb(0, 0, 0)
      });

      yPosition -= 20;
    });

    yPosition -= 20;

    // Totals
    page.drawText('Total Business Expenses:', {
      x: 50,
      y: yPosition,
      size: 12,
      font: boldFont,
      color: rgb(0, 0, 0)
    });
    page.drawText(`$${totalExpenses.toFixed(2)}`, {
      x: 310,
      y: yPosition,
      size: 12,
      font: boldFont,
      color: rgb(0, 0, 0)
    });
    yPosition -= 20;

    page.drawText('Total Deductible Amount:', {
      x: 50,
      y: yPosition,
      size: 12,
      font: boldFont,
      color: rgb(0, 0, 0)
    });
    page.drawText(`$${totalDeductible.toFixed(2)}`, {
      x: 310,
      y: yPosition,
      size: 12,
      font: boldFont,
      color: rgb(0, 0, 0)
    });
    yPosition -= 40;

    // Meals section (if applicable)
    const mealsItem = lineItems['Meals'];
    if (mealsItem) {
      page.drawText('Meals and Entertainment (50% Deductible)', {
        x: 50,
        y: yPosition,
        size: 12,
        font: boldFont,
        color: rgb(0, 0, 0)
      });
      yPosition -= 20;

      page.drawText(`Actual Amount: $${mealsItem.total.toFixed(2)}`, {
        x: 70,
        y: yPosition,
        size: 10,
        font: font,
        color: rgb(0, 0, 0)
      });
      yPosition -= 15;

      page.drawText(`Deductible Amount (50%): $${mealsItem.deductible.toFixed(2)}`, {
        x: 70,
        y: yPosition,
        size: 10,
        font: font,
        color: rgb(0, 0, 0)
      });
      yPosition -= 30;
    }

    // Other expenses detail (if applicable)
    const otherItem = lineItems['Other'];
    if (otherItem && otherItem.transactions.length > 0) {
      page.drawText('Other Expenses Detail (Line 27a)', {
        x: 50,
        y: yPosition,
        size: 12,
        font: boldFont,
        color: rgb(0, 0, 0)
      });
      yPosition -= 20;

      otherItem.transactions.slice(0, 10).forEach((transaction, index) => {
        if (yPosition < 100) {
          // Add new page if running out of space
          page = pdfDoc.addPage([612, 792]);
          yPosition = 750;
        }

        const description = transaction.description || transaction.merchant_name;
        page.drawText(`${index + 1}. ${description} - $${Math.abs(transaction.amount).toFixed(2)}`, {
          x: 70,
          y: yPosition,
          size: 9,
          font: font,
          color: rgb(0, 0, 0)
        });
        yPosition -= 15;
      });

      if (otherItem.transactions.length > 10) {
        yPosition -= 10;
        page.drawText(`... and ${otherItem.transactions.length - 10} more items`, {
          x: 70,
          y: yPosition,
          size: 9,
          font: font,
          color: rgb(0.5, 0.5, 0.5)
        });
      }
    }

    // Footer
    yPosition -= 40;
    page.drawText('Note: This is a summary document. Please consult with your tax professional for proper filing.', {
      x: 50,
      y: yPosition,
      size: 8,
      font: font,
      color: rgb(0.5, 0.5, 0.5)
    });

    // Generate PDF bytes
    const pdfBytes = await pdfDoc.save();

    console.log('✅ [Schedule C Export] PDF generated successfully:', {
      year,
      lineItems: sortedLineItems.length,
      totalExpenses,
      totalDeductible
    });

    // Return PDF as response
    return new NextResponse(pdfBytes, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="schedule-c-${year}.pdf"`,
        'Content-Length': pdfBytes.length.toString()
      }
    });

  } catch (error) {
    console.error('❌ [Schedule C Export] Unexpected error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
