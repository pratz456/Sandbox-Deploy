import { NextRequest, NextResponse } from 'next/server';
import { getTransactionsServer } from '@/lib/firebase/transactions-server';
import { getAuthenticatedUser } from '@/lib/firebase/api-auth';

export async function GET(request: NextRequest) {
  try {
    console.log('🔄 [Transactions API] Starting request...');
    
    // Get the authenticated user
    const { user, error: authError } = await getAuthenticatedUser(request);
    
    if (authError || !user) {
      console.error('❌ [Transactions API] Authentication failed:', authError);
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    console.log('✅ [Transactions API] User authenticated:', user.uid);

    // Parse query parameters for field selection
    const { searchParams } = new URL(request.url);
    const fieldsParam = searchParams.get('fields');
    const fields = fieldsParam ? fieldsParam.split(',') : undefined;
    
    if (fields) {
      console.log('📋 [Transactions API] Requested fields:', fields);
    }

    // Get transactions using Firebase with field selection
    const { data: transactions, error } = await getTransactionsServer(user.uid, fields);

    if (error) {
      console.error('❌ [Transactions API] Error fetching transactions:', error);
      console.error('❌ [Transactions API] Error type:', typeof error);
      console.error('❌ [Transactions API] Error details:', JSON.stringify(error, null, 2));
      
      // Provide more specific error messages
      let errorMessage = 'Failed to fetch transactions';
      if (error.code === 'permission-denied') {
        errorMessage = 'Permission denied. Please check your authentication.';
      } else if (error.code === 'unavailable') {
        errorMessage = 'Database temporarily unavailable. Please try again.';
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      return NextResponse.json({ error: errorMessage }, { status: 500 });
    }

    // Transform transactions based on requested fields
    let transformedTransactions = transactions || [];
    
    if (fields && fields.length > 0) {
      // Filter transactions to only include requested fields
      transformedTransactions = transactions?.map(transaction => {
        const filtered: any = {};
        fields.forEach(field => {
          if (field in transaction) {
            filtered[field] = transaction[field as keyof typeof transaction];
          }
        });
        return filtered;
      }) || [];
    }

    console.log('🔍 [Transactions API] Server-side fetched transactions:', {
      originalCount: transactions?.length || 0,
      transformedCount: transformedTransactions.length,
      userId: user.uid,
      fieldsRequested: fields,
    });

    // Debug: check first 5 transactions' is_deductible values (if field is requested)
    if (!fields || fields.includes('is_deductible')) {
      console.log('🔍 [Transactions API] First 5 transactions is_deductible values:', 
        transactions?.slice(0, 5).map(t => ({
          id: t.trans_id,
          merchant: t.merchant_name,
          category: t.category,
          is_deductible: t.is_deductible,
          is_deductible_type: typeof t.is_deductible,
        }))
      );
    }

    const response = NextResponse.json({
      success: true,
      transactions: transformedTransactions,
      count: transformedTransactions.length,
      fields: fields || 'all',
    });

    // Add cache headers for better performance
    response.headers.set('Cache-Control', 'private, max-age=120'); // 2 minutes
    response.headers.set('ETag', `"${user.uid}-${transactions?.length || 0}"`);

    return response;
  } catch (error) {
    console.error('❌ [Transactions API] Unexpected error:', error);
    return NextResponse.json(
      { 
        error: 'Failed to fetch transactions',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
