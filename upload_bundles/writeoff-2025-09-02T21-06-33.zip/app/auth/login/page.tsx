import { LoginForm } from "@/components/login-form";

export default function Page() {
  return <LoginForm />;
}
