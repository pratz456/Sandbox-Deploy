"use client";

import React, { useState, useEffect } from 'react';
import { Search, Calendar, ArrowUpDown, Filter, Camera, Plus, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/lib/firebase/auth-context';
import { auth } from '@/lib/firebase/client';
import { useRouter } from 'next/navigation';

interface Transaction {
  id: string;
  merchant_name: string;
  amount: number;
  category: string;
  date: string;
  is_deductible?: boolean | null;
  deductible_reason?: string;
  deduction_score?: number;
  notes?: string;
}

export default function TransactionsPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const router = useRouter();

  const { user, loading: authLoading } = useAuth();

  useEffect(() => {
    if (authLoading) {
      console.log('🔄 Auth still loading, waiting...');
      return;
    }
    
    if (user) {
      console.log('👤 User authenticated, fetching transactions...');
      // Add a small delay to ensure cookies are set
      setTimeout(() => {
        fetchTransactions();
      }, 100);
    } else {
      console.log('❌ No authenticated user found');
      setLoading(false);
    }
  }, [user, authLoading]);
  
  const fetchTransactions = async () => {
    try {
      if (!user) {
        console.log('❌ No user found, skipping transaction fetch');
        return;
      }

      console.log('🔍 Fetching transactions for user:', user.id);
      
      // Get fresh token directly from Firebase Auth
      const currentUser = auth.currentUser;
      if (!currentUser) {
        console.log('❌ No current Firebase user found');
        return;
      }
      
      const token = await currentUser.getIdToken();
      console.log('🔑 Got fresh token, making API call...');
      
      const response = await fetch('/api/transactions', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
    
      console.log('📡 Response status:', response.status);
      const data = await response.json();
      console.log('📊 Response data:', data);
      
      if (data.success && data.transactions) {
        setTransactions(data.transactions);
        console.log('✅ Transactions loaded:', data.transactions.length);
      } else {
        console.error('Failed to fetch transactions:', data.error);
      }
    } catch (error) {
      console.error('Error fetching transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  // Calculate summary statistics
  const deductibleTransactions = transactions.filter(t => t.is_deductible === true);
  const personalTransactions = transactions.filter(t => t.is_deductible === false);
  const pendingTransactions = transactions.filter(t => t.is_deductible === null || t.is_deductible === undefined);
  
  const deductibleTotal = deductibleTransactions.reduce((sum, t) => sum + Math.abs(t.amount), 0);
  const pendingTotal = pendingTransactions.reduce((sum, t) => sum + Math.abs(t.amount), 0);
  const potentialSavings = deductibleTotal * 0.3; // 30% tax rate

  // Filter transactions based on active tab
  const getFilteredTransactions = () => {
    let filtered = transactions;
    
    if (activeTab === 'deductible') {
      filtered = transactions.filter(t => t.is_deductible === true);
    } else if (activeTab === 'personal') {
      filtered = transactions.filter(t => t.is_deductible === false);
    } else if (activeTab === 'pending') {
      filtered = transactions.filter(t => t.is_deductible === null || t.is_deductible === undefined);
    }

    if (searchTerm) {
      filtered = filtered.filter(t => 
        t.merchant_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.category.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return filtered;
  };

  const getStatusBadge = (transaction: Transaction) => {
    const confidenceScore = transaction.deduction_score ? Math.round(transaction.deduction_score * 100) : null;
    
    if (transaction.is_deductible === true) {
      return (
        <div className="flex items-center gap-2">
          <Badge className="bg-green-100 text-green-700">Deductible</Badge>
          {confidenceScore && (
            <Badge className="bg-blue-100 text-blue-700 text-xs">
              🤖 {confidenceScore}%
            </Badge>
          )}
        </div>
      );
    } else if (transaction.is_deductible === false) {
      return (
        <div className="flex items-center gap-2">
          <Badge className="bg-red-100 text-red-700">Personal</Badge>
          {confidenceScore && (
            <Badge className="bg-blue-100 text-blue-700 text-xs">
              🤖 {confidenceScore}%
            </Badge>
          )}
        </div>
      );
    } else {
      return (
        <div className="flex items-center gap-2">
          <Badge className="bg-orange-100 text-orange-700">Pending</Badge>
          {confidenceScore && (
            <Badge className="bg-blue-100 text-blue-700 text-xs">
              🤖 {confidenceScore}%
            </Badge>
          )}
        </div>
      );
    }
  };

  const getCategoryBadge = (category: string) => {
    const categoryColors: { [key: string]: string } = {
      'PROFESSIONAL_SERVICES': 'bg-blue-100 text-blue-700',
      'OFFICE_EXPENSE': 'bg-purple-100 text-purple-700',
      'MEALS': 'bg-orange-100 text-orange-700',
      'TRANSPORTATION_TAXIS_AND_RIDE_SHARES': 'bg-green-100 text-green-700',
      'TRAVEL_FLIGHTS': 'bg-indigo-100 text-indigo-700',
      'FOOD_AND_DRINK_COFFEE': 'bg-orange-100 text-orange-700',
      'FOOD_AND_DRINK_FAST_FOOD': 'bg-orange-100 text-orange-700',
      'GENERAL_MERCHANDISE_OTHER_GENERAL_MERCHANDISE': 'bg-gray-100 text-gray-700',
      'GENERAL_SERVICES_ACCOUNTING_AND_FINANCIAL_PLANNING': 'bg-blue-100 text-blue-700',
      'PERSONAL_CARE_GYMS_AND_FITNESS_CENTERS': 'bg-pink-100 text-pink-700',
      'ENTERTAINMENT_SPORTING_EVENTS_AMUSEMENT_PARKS_AND_MUSEUMS': 'bg-purple-100 text-purple-700',
      'GENERAL_MERCHANDISE_SPORTING_GOODS': 'bg-green-100 text-green-700',
      'INCOME_WAGES': 'bg-green-100 text-green-700',
      'LOAN_PAYMENTS_CREDIT_CARD_PAYMENT': 'bg-red-100 text-red-700'
    };

    const colorClass = categoryColors[category] || 'bg-gray-100 text-gray-700';
    const displayName = category.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    
    return <Badge className={colorClass}>{displayName}</Badge>;
  };

  const formatCategory = (category: string): string => {
    if (!category) return 'Uncategorized';
    return category
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-lg">Loading transactions...</div>
      </div>
    );
  }

  const filteredTransactions = getFilteredTransactions();

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-6 lg:mb-8">
        <div 
          className="bg-white rounded-xl p-4 lg:p-6 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => {
            console.log('Deductible transactions card clicked');
            setActiveTab('deductible');
          }}
        >
          <div className="text-xl lg:text-2xl font-bold text-gray-900">${deductibleTotal.toFixed(2)}</div>
          <div className="text-xs lg:text-sm text-gray-600">{deductibleTransactions.length} deductible</div>
        </div>
        <div 
          className="bg-white rounded-xl p-4 lg:p-6 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => {
            console.log('Pending transactions card clicked');
            setActiveTab('pending');
          }}
        >
          <div className="text-xl lg:text-2xl font-bold text-gray-900">${pendingTotal.toFixed(2)}</div>
          <div className="text-xs lg:text-sm text-gray-600">{pendingTransactions.length} needs review</div>
        </div>
        <div 
          className="bg-white rounded-xl p-4 lg:p-6 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => {
            console.log('Potential savings card clicked');
            // Could navigate to reports page or show savings breakdown
          }}
        >
          <div className="text-xl lg:text-2xl font-bold text-gray-900">${potentialSavings.toFixed(2)}</div>
          <div className="text-xs lg:text-sm text-gray-600">Potential savings</div>
        </div>
        <div 
          className="bg-white rounded-xl p-4 lg:p-6 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => {
            console.log('Total transactions card clicked');
            setActiveTab('all');
          }}
        >
          <div className="text-xl lg:text-2xl font-bold text-gray-900">{transactions.length}</div>
          <div className="text-xs lg:text-sm text-gray-600">Total transactions</div>
        </div>
      </div>

      {/* Search and Filter Bar */}
      <div className="bg-white rounded-xl p-4 shadow-sm mb-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex-1 relative w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div 
              className="flex items-center gap-2 px-3 py-2 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50 flex-1 sm:flex-none"
              onClick={() => {
                // Date range selector functionality
                console.log('Date range selector clicked');
                // Could open a date picker modal
              }}
            >
              <Calendar className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-600">Jan 1 - Aug 21</span>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                // Sort functionality - toggle between ascending and descending
                const sorted = [...transactions].sort((a, b) => {
                  const dateA = new Date(a.date).getTime();
                  const dateB = new Date(b.date).getTime();
                  return dateB - dateA; // Most recent first
                });
                setTransactions(sorted);
              }}
            >
              <ArrowUpDown className="w-4 h-4 mr-2" />
              Sort
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="relative"
              onClick={() => {
                // Filter functionality - could open a filter modal
                console.log('Filter button clicked');
              }}
            >
              <Filter className="w-4 h-4 mr-2" />
              Filters
              <Badge className="absolute -top-1 -right-1 bg-blue-600 text-white text-xs">1</Badge>
            </Button>
          </div>
        </div>
        <div className="flex items-center gap-2 mt-3 text-sm text-gray-500">
          <span>1 filter active</span>
          <button 
            className="text-gray-400 hover:text-gray-600"
            onClick={() => {
              // Clear filter functionality
              setSearchTerm('');
              setActiveTab('all');
            }}
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Status Tabs */}
      <div className="flex flex-wrap gap-1 mb-6 overflow-x-auto pb-2">
        <button
          onClick={() => setActiveTab('all')}
          className={`px-3 lg:px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
            activeTab === 'all'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-gray-600 hover:bg-gray-50'
          }`}
        >
          All ({transactions.length})
        </button>
        <button
          onClick={() => setActiveTab('deductible')}
          className={`px-3 lg:px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
            activeTab === 'deductible'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-gray-600 hover:bg-gray-50'
          }`}
        >
          Deductible ({deductibleTransactions.length})
        </button>
        <button
          onClick={() => setActiveTab('personal')}
          className={`px-3 lg:px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
            activeTab === 'personal'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-gray-600 hover:bg-gray-50'
          }`}
        >
          Personal ({personalTransactions.length})
        </button>
        <button
          onClick={() => setActiveTab('pending')}
          className={`px-3 lg:px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
            activeTab === 'pending'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-gray-600 hover:bg-gray-50'
          }`}
        >
          Pending ({pendingTransactions.length})
        </button>
      </div>

      {/* Transaction List - Mobile Card View / Desktop Table View */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        {/* Mobile Card View */}
        <div className="block lg:hidden">
          <div className="divide-y divide-gray-200">
            {filteredTransactions.map((transaction) => (
              <div 
                key={transaction.id} 
                className="p-4 hover:bg-gray-50 cursor-pointer"
                onClick={() => {
                  // Navigate to transaction detail screen
                  router.push(`/protected?screen=transaction-detail&transactionId=${transaction.id}`);
                }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-gray-900 mb-1">
                      {transaction.merchant_name}
                    </div>
                    {transaction.notes && (
                      <div className="text-sm text-gray-500 mb-2">{transaction.notes}</div>
                    )}
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs text-gray-500">
                        {new Date(transaction.date).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric'
                        })}
                      </span>
                      <span className="text-gray-300">•</span>
                      {getCategoryBadge(transaction.category)}
                    </div>
                  </div>
                  <div className="text-right ml-4">
                    <div className="text-sm font-medium text-gray-900 mb-1">
                      ${Math.abs(transaction.amount).toFixed(2)}
                    </div>
                    {getStatusBadge(transaction)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Desktop Table View */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Merchant
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Category
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredTransactions.map((transaction) => (
                <tr 
                  key={transaction.id} 
                  className="hover:bg-gray-50 cursor-pointer"
                  onClick={() => {
                    // Navigate to transaction detail screen
                    router.push(`/protected?screen=transaction-detail&transactionId=${transaction.id}`);
                  }}
                >
                  <td className="px-6 py-4">
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {transaction.merchant_name}
                      </div>
                      {transaction.notes && (
                        <div className="text-sm text-gray-500">{transaction.notes}</div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {new Date(transaction.date).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric'
                    })}
                  </td>
                  <td className="px-6 py-4">
                    {getCategoryBadge(transaction.category)}
                  </td>
                  <td className="px-6 py-4">
                    {getStatusBadge(transaction)}
                  </td>
                  <td className="px-6 py-4 text-right text-sm font-medium text-gray-900">
                    ${Math.abs(transaction.amount).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Top Right Action Buttons */}
      <div className="fixed bottom-6 right-6 flex gap-3 z-50">
        <Button 
          className="bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
          onClick={() => {
            // Receipt upload functionality
            console.log('Receipt upload clicked');
            // Could open a file upload modal or navigate to receipt upload page
          }}
        >
          <Camera className="w-4 h-4 mr-2" />
          <span className="hidden sm:inline">Receipt</span>
        </Button>
        <Button 
          className="bg-blue-600 hover:bg-blue-700"
          onClick={() => {
            // Add transaction functionality
            console.log('Add transaction clicked');
            // Could open a modal to add a new transaction
          }}
        >
          <Plus className="w-4 h-4 mr-2" />
          <span className="hidden sm:inline">+ Add</span>
        </Button>
      </div>
    </div>
  );
}
