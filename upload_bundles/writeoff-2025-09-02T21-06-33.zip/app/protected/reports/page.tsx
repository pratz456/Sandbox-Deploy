"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { FileText, TrendingUp, Calendar, BarChart3, AlertCircle } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/lib/firebase/auth-context';
import { useMonthlyDeductions } from '@/lib/react-query/hooks';
import { ReportsChartSkeleton, PageHeaderSkeleton } from '@/components/ui/skeleton';

interface MonthlyData {
  month: number;
  monthName: string;
  total: number;
  count: number;
}

interface ReportsData {
  monthlyData: MonthlyData[];
  summary: {
    currentMonthTotal: number;
    monthOverMonthChange: number;
    avgMonthly: number;
    monthsWithData: number;
    yearToDateTotal: number;
    estimatedRefund: number;
  };
}

export default function ReportsPage() {
  const router = useRouter();
  const { user, loading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');

  // Use React Query for data fetching with caching
  const { 
    data: reportsResult, 
    isLoading, 
    error, 
    refetch 
  } = useMonthlyDeductions(user?.id || '');

  const reportsData = reportsResult?.data as ReportsData | undefined;

  // Show loading state while auth is loading or data is fetching
  if (authLoading || isLoading) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen">
        <PageHeaderSkeleton />
        <ReportsChartSkeleton />
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-white p-6 rounded-lg border animate-pulse">
            <div className="h-4 w-24 mb-3 bg-gray-200 rounded"></div>
            <div className="h-8 w-32 mb-2 bg-gray-200 rounded"></div>
            <div className="h-3 w-20 bg-gray-200 rounded"></div>
          </div>
          <div className="bg-white p-6 rounded-lg border animate-pulse">
            <div className="h-4 w-24 mb-3 bg-gray-200 rounded"></div>
            <div className="h-8 w-32 mb-2 bg-gray-200 rounded"></div>
            <div className="h-3 w-20 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Error Loading Reports</h2>
          <p className="text-gray-600 mb-4">
            {error instanceof Error ? error.message : 'Failed to load reports data'}
          </p>
          <Button 
            onClick={() => refetch()}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  if (!reportsData) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen">
        <div className="text-center text-gray-500">
          <AlertCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">No Reports Data</h2>
          <p className="text-gray-600 mb-4">
            No reports data is available. This could be because:
          </p>
          <ul className="text-gray-600 text-left max-w-md mx-auto mb-4">
            <li>• You haven't imported any transactions yet</li>
            <li>• Your transactions haven't been analyzed for deductions</li>
            <li>• There was an issue loading your data</li>
          </ul>
          <Button 
            onClick={() => refetch()}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            Refresh
          </Button>
        </div>
      </div>
    );
  }

  const { monthlyData, summary } = reportsData;
  
  // Calculate dynamic Y-axis scaling based on actual data
  const dataValues = monthlyData.map(m => m.total).filter(val => val > 0);
  const dataMax = Math.max(...dataValues, 0);
  const maxAmount = dataMax > 0 ? Math.ceil(dataMax * 1.2) : 100; // Add 20% padding above highest value

  // Check if we have any meaningful data
  const hasData = dataValues.length > 0 && dataMax > 0;

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4 mb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Reports</h1>
          <p className="text-gray-600">Your tax deduction analysis and savings summary</p>
        </div>
        <Button 
          className="bg-blue-600 hover:bg-blue-700 text-white self-start sm:self-auto"
          onClick={() => {
            // Generate report functionality
            console.log('Generate report clicked');
            // Could trigger report generation or download
          }}
        >
          <FileText className="w-4 h-4 mr-2" />
          Generate Report
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 mb-6 bg-white rounded-lg p-1 w-fit">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'overview'
              ? 'bg-white text-gray-900 shadow-sm'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Overview
        </button>
      </div>

      {activeTab === 'overview' && (
        <>
          {/* Monthly Tax Savings Chart */}
          <Card className="p-4 lg:p-6 bg-white border-0 shadow-sm mb-6">
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3 mb-6">
              <h2 className="text-lg lg:text-xl font-semibold text-gray-900">Monthly Estimated Tax Savings</h2>
              <span className="text-sm text-gray-500">2024</span>
            </div>

            {!hasData ? (
              <div className="text-center py-8 lg:py-12">
                <BarChart3 className="w-12 h-12 lg:w-16 lg:h-16 text-gray-300 mx-auto mb-3 lg:mb-4" />
                <p className="text-gray-500 mb-2">No tax savings data available</p>
                <p className="text-sm text-gray-400">
                  Import and analyze your transactions to see your tax savings
                </p>
              </div>
            ) : (
              <>
                {/* Chart */}
                <div className="relative mb-4 ml-12 lg:ml-16" style={{ height: '200px', minHeight: '200px' }}>
                  {/* Y-axis labels */}
                  <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-gray-400 -ml-12 lg:-ml-16 w-10 lg:w-14 text-right">
                    <span>${maxAmount.toFixed(0)}</span>
                    <span>${(maxAmount * 0.75).toFixed(0)}</span>
                    <span>${(maxAmount * 0.5).toFixed(0)}</span>
                    <span>${(maxAmount * 0.25).toFixed(0)}</span>
                    <span>$0</span>
                  </div>

                  {/* Chart bars */}
                  <div className="relative px-2 lg:px-4" style={{ height: '200px' }}>
                    <div className="flex items-end justify-between h-full">
                      {monthlyData.map((month, index) => {
                        const barHeightPx = month.total > 0 ? Math.max((month.total / maxAmount) * 200, 8) : 0;
                        
                        return (
                          <div key={month.month} className="flex flex-col items-center" style={{ width: '8.33%' }}>
                            {/* Bar */}
                            <div 
                              className="w-full bg-blue-500 hover:bg-blue-600 transition-all duration-300 cursor-pointer rounded-t-sm mb-2 relative group"
                              style={{
                                height: `${barHeightPx}px`,
                                maxWidth: '24px'
                              }}
                              onClick={() => {
                                // Chart bar click functionality
                                console.log(`Clicked on ${month.monthName} - Tax Savings: $${month.total.toFixed(2)}`);
                                // Could open detailed breakdown for this month
                              }}
                            >
                              {/* Tooltip */}
                              {month.total > 0 && (
                                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap pointer-events-none z-10">
                                  ${month.total.toFixed(2)}
                                </div>
                              )}
                            </div>
                            
                            {/* Month label */}
                            <span className="text-xs text-gray-500 mt-1">{month.monthName}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Chart link */}
                <div className="text-center">
                  <button 
                    className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                    onClick={() => {
                      // Chart interaction functionality
                      console.log('Chart bars clicked');
                      // Could open detailed monthly breakdown modal
                    }}
                  >
                    Tap bars to view detailed monthly tax savings breakdown
                  </button>
                </div>
              </>
            )}
          </Card>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            {/* This Month Card */}
            <Card 
              className="p-4 lg:p-6 bg-white border-0 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => {
                console.log('This month card clicked');
                // Could show detailed breakdown for current month
              }}
            >
              <div className="flex items-center gap-3 mb-3">
                <Calendar className="w-5 h-5 text-gray-600" />
                <h3 className="text-sm font-medium text-gray-700">This Month</h3>
              </div>
              <div className="text-xl lg:text-2xl font-bold text-gray-900 mb-1">
                ${summary.currentMonthTotal.toFixed(2)}
              </div>
              <div className="text-sm text-green-600 font-medium">
                +{summary.monthOverMonthChange.toFixed(0)}% vs last month
              </div>
            </Card>

            {/* Avg Monthly Card */}
            <Card 
              className="p-4 lg:p-6 bg-white border-0 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => {
                console.log('Average monthly tax savings card clicked');
                // Could show monthly averages breakdown
              }}
            >
              <div className="flex items-center gap-3 mb-3">
                <TrendingUp className="w-5 h-5 text-gray-600" />
                <h3 className="text-sm font-medium text-gray-700">Avg Monthly Tax Savings</h3>
              </div>
              <div className="text-xl lg:text-2xl font-bold text-gray-900 mb-1">
                ${summary.avgMonthly.toFixed(2)}
              </div>
              <div className="text-sm text-gray-500">
                Based on {summary.monthsWithData} months
              </div>
            </Card>
          </div>

          {/* Ready to File Section */}
          <Card 
            className="p-4 lg:p-6 bg-white border-0 shadow-sm mb-6 cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => {
              console.log('Ready to file section clicked');
              // Could expand to show more filing details
            }}
          >
            <h3 className="text-lg lg:text-xl font-semibold text-gray-900 mb-4">Ready to File?</h3>
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                <span className="text-gray-700">Estimated Federal Refund</span>
                <span className="text-xl lg:text-2xl font-bold text-green-600">
                  ${summary.estimatedRefund.toFixed(2)}
                </span>
              </div>
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                <span className="text-gray-700">State Tax Owed</span>
                <span className="text-xl lg:text-2xl font-bold text-orange-600">
                  $456.00
                </span>
              </div>
              <div className="border-t border-gray-200 pt-3">
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                  <span className="text-gray-700 font-medium">Net Refund</span>
                  <span className="text-xl lg:text-2xl font-bold text-green-600">
                    ${(summary.estimatedRefund - 456).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </Card>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <Button 
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3"
              onClick={() => {
                router.push('/protected/schedule-c');
              }}
            >
              <FileText className="w-4 h-4 mr-2" />
              Export Schedule C
            </Button>
          </div>
        </>
      )}
    </div>
  );
}
