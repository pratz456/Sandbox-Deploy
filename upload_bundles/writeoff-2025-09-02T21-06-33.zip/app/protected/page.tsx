"use client";

import { useAuth } from "@/lib/firebase/auth-context";
import { getUserProfile } from "@/lib/firebase/profiles";
import { ProfileSetupScreen } from "@/components/profile-setup-screen";
import DashboardScreen from "@/components/dashboard-screen";
import { SettingsScreen } from "@/components/settings-screen";
import { DebugProfile } from "@/components/debug-profile";
import { AddExpenseScreen } from "@/components/add-expense-screen";
import { ReceiptUploadScreen } from "@/components/receipt-upload-screen";
import { TaxCalendarScreen } from "@/components/tax-calendar-screen";
import { TransactionDetailScreen } from "@/components/transaction-detail-screen";
import { ReviewTransactionsScreen } from "@/components/review-transactions-screen";
import { ScheduleCExportScreen } from "@/components/schedule-c-export-screen";
import { DeductionsDetailScreen } from "@/components/deductions-detail-screen";
import { ExpensesDetailScreen } from "@/components/expenses-detail-screen";
import { BanksDetailScreen } from "@/components/banks-detail-screen";
import { ProfitLossDetailScreen } from "@/components/profit-loss-detail-screen";
import { CategoriesScreen } from "@/components/categories-screen";
import { PlaidLinkScreen } from "@/components/plaid-link-screen";
import { PlaidScreen } from "@/components/plaid-screen";
import { getTransactions } from "@/lib/firebase/transactions";
import { syncTransactions } from "@/lib/api";
import { auth } from "@/lib/firebase/client";
import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

interface UserProfile {
  email: string;
  name: string;
  profession: string;
  income: string;
  state: string;
  filingStatus: string;
  plaidToken?: string;
}

interface Transaction {
  id: string;
  merchant_name: string;
  amount: number;
  category: string;
  date: string;
  type?: 'expense' | 'income';
  is_deductible?: boolean | null;
  deductible_reason?: string;
  deduction_score?: number;
  description?: string;
  notes?: string;
}

export default function ProtectedPage() {
  const { user, loading } = useAuth();
  const [userProfile, setUserProfile] = useState<any>(null);
  const [hasProfile, setHasProfile] = useState<boolean | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentScreen, setCurrentScreen] = useState<'dashboard' | 'settings' | 'debug' | 'add-expense' | 'receipt-upload' | 'tax-calendar' | 'transactions' | 'review-transactions' | 'schedule-c-export' | 'edit-expense' | 'deductions-detail' | 'expenses-detail' | 'banks-detail' | 'profit-loss-detail' | 'categories' | 'plaid-link' | 'plaid' | 'transaction-detail' | 'reports'>('dashboard');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [viewingTransaction, setViewingTransaction] = useState<Transaction | null>(null);
  const [loadingTransactions, setLoadingTransactions] = useState(false);
  const [analyzingTransactions, setAnalyzingTransactions] = useState(false);
  const [bankConnected, setBankConnected] = useState(false);
  const router = useRouter();
  const searchParams = useSearchParams();

  // Fetch transactions from database
  const fetchTransactions = async () => {
    if (!user?.id) return;
    
    setLoadingTransactions(true);
    try {
      // Get Firebase auth token
      const currentUser = auth.currentUser;
      if (!currentUser) {
        console.log('❌ No Firebase user found');
        return;
      }
      
      const token = await currentUser.getIdToken();
      console.log('🔑 Got auth token for API call');
      
      // Fetch all transactions from database via server-side API
      console.log('📊 Fetching transactions from database via API...');
      const response = await fetch('/api/transactions', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      const result = await response.json();
      
      if (!response.ok) {
        console.error('Failed to fetch transactions:', result.error);
      } else {
        console.log('📋 Raw transactions from API:', result.transactions);
        console.log('📊 Transaction count:', result.count);
        if (result.transactions && result.transactions.length > 0) {
          console.log('📋 Sample transaction:', result.transactions[0]);
        }
        setTransactions(result.transactions || []);
      }
    } catch (error) {
      console.error('Error fetching transactions:', error);
    } finally {
      setLoadingTransactions(false);
    }
  };

  // Check bank connection and fetch transactions
  const checkBankConnectionAndFetchTransactions = async (currentUser: any) => {
    try {
      // Check if user has a Plaid token in their profile
      const { data: profile, error } = await getUserProfile(currentUser.id);
      
      if (profile?.plaid_token) {
        setBankConnected(true);
        // Only sync transactions if explicitly requested, not on every page load
        // This prevents the massive slowdown on home screen
        console.log('✅ Bank connected - transactions will be synced on demand');
        
        // Fetch existing transactions from database (fast)
        await fetchTransactions();
      } else {
        setBankConnected(false);
        // Still fetch any existing transactions
        await fetchTransactions();
      }
    } catch (error) {
      console.error('Error checking bank connection:', error);
      setBankConnected(false);
      // Still fetch any existing transactions
      await fetchTransactions();
    }
  };

  useEffect(() => {
    const checkUserAndProfile = async () => {
      if (!user) {
        setIsLoading(false);
        return;
      }

      try {

        // Check if user has completed profile setup
        const { data: profile, error: profileError } = await getUserProfile(user.id);
        
        if (profileError) {
          // PGRST116 means no rows returned (user has no profile yet)
          if (profileError.code === 'PGRST116') {
            console.log('No profile found for user, showing setup screen');
            setHasProfile(false);
          } else {
            console.error('Error checking profile:', profileError);
            
            // Check if it's a permissions error
            if (profileError?.message?.includes('permissions') || profileError?.code === 'permission-denied') {
              console.log('Permissions issue detected, user needs to set up profile');
              setHasProfile(false);
            } else {
              console.log('Other profile error, defaulting to profile setup');
              setHasProfile(false);
            }
          }
        } else {
          setHasProfile(!!profile);
          setUserProfile(profile);
          // If user has profile, check bank connection and fetch transactions
          if (profile) {
            await checkBankConnectionAndFetchTransactions(user);
          }
        }
      } catch (error) {
        console.error('Error in checkUserAndProfile:', error);
        router.push("/auth/login");
      } finally {
        setIsLoading(false);
      }
    };

    checkUserAndProfile();
  }, [user, router]);

  // Refresh transactions when navigating to dashboard
  useEffect(() => {
    if (currentScreen === 'dashboard' && user?.id && hasProfile === true) {
      fetchTransactions();
    }
  }, [currentScreen, user?.id, hasProfile]);

  // Handle URL parameters for navigation
  useEffect(() => {
    if (searchParams) {
      const screen = searchParams.get('screen');
      const transactionId = searchParams.get('transactionId');
      
      if (screen === 'transaction-detail' && transactionId) {
        // Find the transaction by ID
        const transaction = transactions.find(t => t.id === transactionId);
        if (transaction) {
          setViewingTransaction(transaction);
          setCurrentScreen('transaction-detail');
        }
      } else if (screen) {
        setCurrentScreen(screen as any);
      }
    }
  }, [searchParams, transactions]);

  const handleProfileComplete = async (profile: UserProfile) => {
    console.log('Profile setup completed:', profile);
    setHasProfile(true);
    
    // Fetch the complete profile from database to ensure we have all fields
    if (user) {
      try {
        const { data: userProfile, error: profileError } = await getUserProfile(user.id);
        
        if (profileError) {
          console.error('Error fetching user profile after completion:', profileError);
        } else {
          console.log('✅ User profile loaded after completion:', userProfile);
          setUserProfile(userProfile);
        }
        
        // Check bank connection and fetch transactions after profile completion
        await checkBankConnectionAndFetchTransactions(user);
      } catch (error) {
        console.error('Error in handleProfileComplete:', error);
      }
    }
  };

  const handleBack = async () => {
    // Handle logout or back to login
    try {
      const { signOutUser } = await import("@/lib/firebase/auth");
      await signOutUser();
      router.push("/");
    } catch (error) {
      console.error('Error signing out:', error);
      router.push("/");
    }
  };

  // Handle navigation between screens
  const handleNavigate = (screen: string) => {
    console.log('Navigate to:', screen);
    if (screen === 'settings') {
      setCurrentScreen('settings');
    } else if (screen === 'dashboard') {
      setCurrentScreen('dashboard');
    } else if (screen === 'debug') {
      setCurrentScreen('debug');
    } else if (screen === 'categorize' || screen === 'add-expense') {
      setEditingTransaction(null);
      setCurrentScreen('add-expense');
    } else if (screen === 'receipt-upload') {
      setCurrentScreen('receipt-upload');
    } else if (screen === 'tax-calendar') {
      setCurrentScreen('tax-calendar');
    } else if (screen === 'transactions') {
      // Navigate to transactions page using Next.js router
      router.push('/protected/transactions');
    } else if (screen === 'review-transactions') {
      setCurrentScreen('review-transactions');
    } else if (screen === 'schedule-c-export') {
      setCurrentScreen('schedule-c-export');
    } else if (screen === 'deductions-detail') {
      setCurrentScreen('deductions-detail');
    } else if (screen === 'expenses-detail') {
      setCurrentScreen('expenses-detail');
    } else if (screen === 'banks-detail') {
      setCurrentScreen('banks-detail');
    } else if (screen === 'profit-loss-detail') {
      setCurrentScreen('profit-loss-detail');
    } else if (screen === 'categories') {
      setCurrentScreen('categories');
    } else if (screen === 'plaid-link') {
      setCurrentScreen('plaid-link');
    } else if (screen === 'plaid') {
      setCurrentScreen('plaid');
    } else if (screen === 'transaction-detail') {
      setCurrentScreen('transaction-detail');
    } else if (screen === 'reports') {
      // Navigate to reports page using Next.js router
      router.push('/protected/reports');
    }
    // You can add more screen navigation logic here
  };

  // Handle viewing transaction details
  const handleViewTransaction = (transaction: Transaction) => {
    setViewingTransaction(transaction);
    setCurrentScreen('transaction-detail');
  };

  // Handle sign out
  const handleSignOut = async () => {
    try {
      const { signOutUser } = await import("@/lib/firebase/auth");
      await signOutUser();
      router.push("/");
    } catch (error) {
      console.error('Error signing out:', error);
      router.push("/");
    }
  };

  // Handle saving transactions
  const handleSaveTransaction = async (transaction: Transaction) => {
    // Update local state immediately for responsive UI
    setTransactions(prev => {
      const existingIndex = prev.findIndex(t => t.id === transaction.id);
      if (existingIndex >= 0) {
        // Update existing transaction
        const updated = [...prev];
        updated[existingIndex] = transaction;
        return updated;
      } else {
        // Add new transaction
        return [...prev, transaction];
      }
    });
    
    // Also update the viewing transaction if it's the same one
    setViewingTransaction(prev => prev && prev.id === transaction.id ? transaction : prev);
    
    // Re-fetch transactions to ensure consistency with database
    if (user?.id) {
      await fetchTransactions();
    }
  };

  // Handle editing a transaction
  const handleEditTransaction = (transaction: Transaction) => {
    setEditingTransaction(transaction);
    setCurrentScreen('add-expense');
  };

  // Handle transaction update (for review screen)
  const handleTransactionUpdate = async (updatedTransaction: Transaction) => {
    console.log('🔄 [UI RERENDER] Parent handleTransactionUpdate called for:', updatedTransaction.id, 'is_deductible:', updatedTransaction.is_deductible);
    
    // Update local state immediately for responsive UI
    setTransactions(prevTransactions => {
      const updated = prevTransactions.map(t => 
        t.id === updatedTransaction.id ? updatedTransaction : t
      );
      console.log('🔄 [UI RERENDER] Updated local transactions state');
      return updated;
    });
    
    setViewingTransaction(prev => prev && prev.id === updatedTransaction.id ? { ...prev, ...updatedTransaction } : prev);
    
    // Re-fetch transactions to ensure consistency with database
    if (user?.id) {
      console.log('🔄 [UI RERENDER] Re-fetching transactions from database...');
      await fetchTransactions();
      console.log('✅ [UI RERENDER] Transactions re-fetched successfully');
    }
  };

  // Handle receipt upload completion
  const handleReceiptUploadComplete = (expenseData: any) => {
    const transaction: Transaction = {
      id: expenseData.id,
      merchant_name: expenseData.description,
      amount: expenseData.amount,
      category: expenseData.category,
      date: expenseData.date,
      type: 'expense',
      is_deductible: expenseData.isDeductible,
      notes: `Receipt uploaded: ${expenseData.receipt?.fileName || 'receipt.jpg'}`
    };
    handleSaveTransaction(transaction);
  };

  if (loading || isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-8 w-8 border-2 border-primary border-t-transparent mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  // Show profile setup screen if user hasn't completed their profile
  if (user && hasProfile === false) {
    return (
      <ProfileSetupScreen
        user={user}
        onBack={handleBack}
        onComplete={handleProfileComplete}
      />
    );
  }

  // Show dashboard if user has completed profile setup
  if (user && hasProfile === true) {
    if (currentScreen === 'debug') {
      return (
        <div>
          <div className="p-4">
            <button 
              onClick={() => setCurrentScreen('dashboard')} 
              className="mb-4 px-4 py-2 bg-blue-500 text-white rounded"
            >
              Back to Dashboard
            </button>
          </div>
          <DebugProfile user={user} />
        </div>
      );
    }
    
    if (currentScreen === 'settings') {
      return (
        <SettingsScreen
          user={user}
          onBack={() => setCurrentScreen('dashboard')}
          onNavigate={handleNavigate}
        />
      );
    }

    if (currentScreen === 'add-expense') {
      return (
        <AddExpenseScreen
          user={user}
          onBack={() => setCurrentScreen('dashboard')}
          onSave={handleSaveTransaction}
          editingExpense={editingTransaction}
        />
      );
    }

    if (currentScreen === 'receipt-upload') {
      return (
        <ReceiptUploadScreen
          user={user}
          onBack={() => setCurrentScreen('dashboard')}
          onUploadComplete={handleReceiptUploadComplete}
        />
      );
    }

    if (currentScreen === 'tax-calendar') {
      return (
        <TaxCalendarScreen
          user={user}
          onBack={() => setCurrentScreen('dashboard')}
        />
      );
    }



    if (currentScreen === 'review-transactions') {
      return (
        <ReviewTransactionsScreen
          user={user}
          onBack={() => setCurrentScreen('dashboard')}
          transactions={transactions}
          onTransactionUpdate={handleTransactionUpdate}
          onTransactionClick={handleViewTransaction}
        />
      );
    }

    if (currentScreen === 'schedule-c-export') {
      return (
        <ScheduleCExportScreen
          user={user}
          onBack={() => setCurrentScreen('dashboard')}
          transactions={transactions}
        />
      );
    }

    if (currentScreen === 'deductions-detail') {
      return (
        <DeductionsDetailScreen
          user={user}
          onBack={() => setCurrentScreen('dashboard')}
          transactions={transactions}
        />
      );
    }

    if (currentScreen === 'expenses-detail') {
      return (
        <ExpensesDetailScreen
          user={user}
          onBack={() => setCurrentScreen('dashboard')}
          transactions={transactions}
        />
      );
    }

    if (currentScreen === 'banks-detail') {
      return (
        <BanksDetailScreen
          user={user}
          onBack={() => setCurrentScreen('dashboard')}
          onConnectBank={() => {
            // You can implement Plaid connection here or navigate to a connect screen
            setCurrentScreen('dashboard');
          }}
        />
      );
    }

    if (currentScreen === 'profit-loss-detail') {
      return (
        <ProfitLossDetailScreen
          onNavigate={handleNavigate}
          transactions={transactions}
        />
      );
    }

    if (currentScreen === 'categories') {
      return (
        <CategoriesScreen
          user={user}
          onBack={() => setCurrentScreen('dashboard')}
          transactions={transactions}
          onTransactionClick={(transaction) => handleViewTransaction(transaction)}
        />
      );
    }

    if (currentScreen === 'plaid-link') {
      return (
        <PlaidLinkScreen
          user={user}
          onSuccess={() => setCurrentScreen('dashboard')}
          onBack={() => setCurrentScreen('settings')}
        />
      );
    }

    if (currentScreen === 'plaid') {
      return (
        <PlaidScreen
          user={user}
          onBack={() => setCurrentScreen('settings')}
          onConnect={() => setCurrentScreen('plaid-link')}
        />
      );
    }

    if (currentScreen === 'transaction-detail' && viewingTransaction) {
      return (
        <TransactionDetailScreen
          transaction={viewingTransaction}
          onBack={() => setCurrentScreen('dashboard')}
          onSave={handleSaveTransaction}
        />
      );
    }

    if (currentScreen === 'reports') {
      // For reports, we'll redirect to the reports page
      router.push('/protected/reports');
      return null;
    }
    
    return (
      <DashboardScreen 
        profile={userProfile}
        transactions={transactions}
        onNavigate={handleNavigate}
        onTransactionClick={(transaction) => handleViewTransaction(transaction)}
        onAnalyzeTransactions={async () => {
          setAnalyzingTransactions(true);
          try {
            await fetchTransactions();
          } finally {
            setAnalyzingTransactions(false);
          }
        }}
        analyzingTransactions={analyzingTransactions}
        onSignOut={handleSignOut}
      />
    );
  }

  return null;
}
