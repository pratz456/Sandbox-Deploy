"use client";

import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/lib/firebase/auth-context';
import { getUserProfile } from '@/lib/firebase/profiles';
import { Settings, User, CreditCard, Database, LogOut, BookOpen, X } from 'lucide-react';

export default function SettingsPage() {
  const { user, signOut } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showWriteOffsModal, setShowWriteOffsModal] = useState(false);

  useEffect(() => {
    const fetchUserAndProfile = async () => {
      try {
        if (user) {
          const { data: profile } = await getUserProfile(user.id);
          setProfile(profile);
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUserAndProfile();
  }, [user]);

  const handleSignOut = async () => {
    try {
      await signOut();
      window.location.href = '/';
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  if (loading) {
    return (
      <div className="p-6 bg-gray-50 min-h-screen">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-32 mb-6"></div>
          <div className="space-y-4">
            <div className="h-24 bg-gray-200 rounded"></div>
            <div className="h-24 bg-gray-200 rounded"></div>
            <div className="h-24 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Settings</h1>
        <p className="text-gray-600">Manage your account and preferences</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Account Settings */}
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <User className="w-5 h-5 text-gray-600" />
            <h2 className="text-xl font-semibold text-gray-900">Account</h2>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <p className="text-gray-900">{user?.email}</p>
            </div>
            {profile && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                  <p className="text-gray-900">{profile.name || 'Not set'}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Profession</label>
                  <p className="text-gray-900">{profile.profession || 'Not set'}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
                  <p className="text-gray-900">{profile.state || 'Not set'}</p>
                </div>
              </>
            )}
          </div>
        </Card>

        {/* Bank Connection */}
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <CreditCard className="w-5 h-5 text-gray-600" />
            <h2 className="text-xl font-semibold text-gray-900">Bank Connection</h2>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Connection Status</span>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                profile?.plaid_token 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-red-100 text-red-800'
              }`}>
                {profile?.plaid_token ? 'Connected' : 'Not Connected'}
              </span>
            </div>
            <Button 
              className="w-full"
              variant={profile?.plaid_token ? "outline" : "default"}
              onClick={() => {
                // Bank connection functionality
                console.log('Bank connection clicked');
                if (profile?.plaid_token) {
                  // Reconnect bank
                  console.log('Reconnecting bank...');
                } else {
                  // Connect bank
                  console.log('Connecting bank...');
                }
              }}
            >
              {profile?.plaid_token ? 'Reconnect Bank' : 'Connect Bank'}
            </Button>
          </div>
        </Card>

        {/* Data Management */}
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <Database className="w-5 h-5 text-gray-600" />
            <h2 className="text-xl font-semibold text-gray-900">Data Management</h2>
          </div>
          <div className="space-y-4">
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => {
                // Export data functionality
                console.log('Export data clicked');
                // Could trigger data export/download
              }}
            >
              Export Data
            </Button>
            <Button 
              variant="outline" 
              className="w-full text-red-600 hover:text-red-700"
              onClick={() => {
                // Delete account functionality
                console.log('Delete account clicked');
                if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
                  console.log('Account deletion confirmed');
                  // Could trigger account deletion process
                }
              }}
            >
              Delete Account
            </Button>
          </div>
        </Card>

        {/* Learn about write-offs */}
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <BookOpen className="w-5 h-5 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-900">Education</h2>
          </div>
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              Learn what expenses are deductible and maximize your tax savings.
            </p>
            <Button 
              onClick={() => setShowWriteOffsModal(true)}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              Learn about write-offs
            </Button>
          </div>
        </Card>

        {/* Sign Out */}
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <LogOut className="w-5 h-5 text-gray-600" />
            <h2 className="text-xl font-semibold text-gray-900">Sign Out</h2>
          </div>
          <div className="space-y-4">
            <Button 
              onClick={handleSignOut}
              variant="outline" 
              className="w-full text-red-600 hover:text-red-700"
            >
              Sign Out
            </Button>
          </div>
        </Card>
      </div>

      {/* Write-offs Educational Modal */}
      {showWriteOffsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between rounded-t-2xl">
              <h2 className="text-2xl font-bold text-gray-900">Learn About Tax Write-offs</h2>
              <button 
                onClick={() => setShowWriteOffsModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6 text-gray-600" />
              </button>
            </div>
            
            <div className="p-6 space-y-8">
              {/* Introduction */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                <h3 className="text-xl font-semibold text-blue-900 mb-3">What are Tax Write-offs?</h3>
                <p className="text-blue-800">
                  Tax write-offs (also called deductions) are legitimate business expenses that reduce your taxable income. 
                  As a freelancer or business owner, you can deduct ordinary and necessary expenses related to your work, 
                  potentially saving you 20-30% of those costs in taxes.
                </p>
              </div>

              {/* Common Deductible Expenses */}
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">✅ Common Deductible Expenses</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-800 mb-2">Office & Equipment</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Computer, software, and tech equipment</li>
                      <li>• Office supplies and furniture</li>
                      <li>• Internet and phone bills (business portion)</li>
                      <li>• Home office expenses</li>
                    </ul>
                  </div>
                  
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-800 mb-2">Professional Services</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Legal and accounting fees</li>
                      <li>• Business consulting</li>
                      <li>• Professional development courses</li>
                      <li>• Industry conferences and workshops</li>
                    </ul>
                  </div>
                  
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-800 mb-2">Travel & Transportation</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Business travel (flights, hotels)</li>
                      <li>• Mileage for business trips</li>
                      <li>• Parking and tolls</li>
                      <li>• Uber/Lyft for business purposes</li>
                    </ul>
                  </div>
                  
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-800 mb-2">Business Operations</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Marketing and advertising</li>
                      <li>• Business insurance</li>
                      <li>• Bank fees and merchant processing</li>
                      <li>• Business licenses and permits</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Meals - Special Rules */}
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
                <h3 className="text-xl font-semibold text-yellow-800 mb-3">🍽️ Business Meals - Special Rules</h3>
                <p className="text-yellow-700 mb-3">
                  Business meals are generally 50% deductible, but there are exceptions:
                </p>
                <ul className="text-sm text-yellow-700 space-y-2">
                  <li>• <strong>Client meetings:</strong> 50% deductible when discussing business</li>
                  <li>• <strong>Team meals:</strong> 50% deductible for employee meals</li>
                  <li>• <strong>Office snacks:</strong> 100% deductible for office-provided food</li>
                  <li>• <strong>Travel meals:</strong> 50% deductible when traveling for business</li>
                </ul>
              </div>

              {/* Non-Deductible Expenses */}
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">❌ Generally NOT Deductible</h3>
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <ul className="text-sm text-red-700 space-y-2">
                    <li>• Personal groceries and household items</li>
                    <li>• Personal clothing (unless it's a uniform)</li>
                    <li>• Personal entertainment and hobbies</li>
                    <li>• Commuting to your regular workplace</li>
                    <li>• Personal insurance and medical expenses</li>
                    <li>• Personal credit card interest</li>
                    <li>• Fines and penalties</li>
                  </ul>
                </div>
              </div>

              {/* Key Requirements */}
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-3">📋 Key Requirements for Deductions</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-700 mb-2">1. Ordinary & Necessary</h4>
                    <p className="text-sm text-gray-600">
                      The expense must be common and accepted in your industry, and helpful for your business.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-700 mb-2">2. Business Purpose</h4>
                    <p className="text-sm text-gray-600">
                      The expense must be directly related to your business activities, not personal use.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-700 mb-2">3. Keep Records</h4>
                    <p className="text-sm text-gray-600">
                      Maintain receipts, invoices, and records showing the business purpose and amount.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-700 mb-2">4. Reasonable Amount</h4>
                    <p className="text-sm text-gray-600">
                      The expense amount should be reasonable and not excessive for the business benefit.
                    </p>
                  </div>
                </div>
              </div>

              {/* Tips */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                <h3 className="text-xl font-semibold text-blue-800 mb-3">💡 Pro Tips</h3>
                <ul className="text-sm text-blue-700 space-y-2">
                  <li>• <strong>Track everything:</strong> Use WriteOff to automatically categorize your expenses</li>
                  <li>• <strong>Mixed-use items:</strong> Only deduct the business portion (e.g., 70% of home internet if 70% is for business)</li>
                  <li>• <strong>When in doubt:</strong> Consult with a tax professional</li>
                  <li>• <strong>Stay organized:</strong> Keep digital copies of all receipts and invoices</li>
                  <li>• <strong>Be conservative:</strong> Only claim legitimate business expenses</li>
                </ul>
              </div>

              {/* Disclaimer */}
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                <p className="text-xs text-amber-700">
                  <strong>Disclaimer:</strong> This information is for educational purposes only and should not be considered tax advice. 
                  Tax laws vary by location and situation. Always consult with a qualified tax professional for advice specific to your circumstances.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
